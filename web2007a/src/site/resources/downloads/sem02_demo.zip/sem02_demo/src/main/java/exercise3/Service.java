package exercise3;

public interface Service {

}
