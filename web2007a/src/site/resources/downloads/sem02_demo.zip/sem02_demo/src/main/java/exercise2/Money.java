package exercise2;

public class Money {

    private float amount;

    public void setAmount(float amount) {
        this.amount = stripToTwoDecimals(amount);
    }

    private float stripToTwoDecimals(float amount) {
        return ((int) (amount * 100)) / 100.0f;
    }

    public float getAmount() {
        return amount;
    }

    public void add(Money anotherMoney) {
        this.amount += anotherMoney.getAmount();
    }
}