package exercise5;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import junit.framework.TestCase;

/**
 * TASK: test AddToShopcartServlet using EasyMock
 */
public class TestAddToShopcartServlet extends TestCase {

    public void testAddTwoApples() throws Exception {
        // 1. create a Shopcart and populate it with 5 apples

        // 2. create a MockControl for HttpSession

        // 3. obtain a HttpSession mock from the control

        // 4. tell the control to return your Shopcart object when someone
        //    calls getAttribute("shoppingCart")

        // 5. create a MockControl for RequestDispatcher

        // 6. obtain a RequestDispatcher mock from the control

        // 7. create a MockControl for HttpServletRequest 

        // 8. obtain a HttpServletRequest mock from the control

        // 9. tell the control to return your mock HttpSession when asked for

        // 10. tell the control to return "apple" when someone queries for the
        //     request parameter named "itemId"

        // 11. tell the control to return "2" when someone queries for the 
        //     request parameter named "quantity"

        // 12. tell the control to return your mock RequestDispatcher when
        //     someone calls getRequestDispatcher("/showCart.jsp")

        // 13. create a MockControl for HttpServletResponse

        // 14. obtain a HttpServletResponse mock from the control

        // 15. switch all controls to replay mode

        // 16. initialize and execute the servlet

        // 17. assert that your Shopcart has 7 apples after the servlet ran

        // 18. ask all controls to verify that their expectations were met
    }

}