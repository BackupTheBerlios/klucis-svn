package exercise2.xml;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

@RunWith(Parameterized.class)
public class ParserWrapperTest {

	private Node node;

	private int nodeType;

	private String nodeName;

	private String nodeText;

	public ParserWrapperTest(int num, int nodeType, String nodeName,
			String nodeText) {
		this.node = getTargetNode(num);
		this.nodeType = nodeType;
		this.nodeName = nodeName;
		this.nodeText = nodeText;
	}

	private static String xmlFile = "<?xml version='1.0'?>"
			+ "<!DOCTYPE poem [ <!ELEMENT poem (line+)> "
			+ "<!ELEMENT line (#PCDATA)><!ATTLIST line num CDATA #IMPLIED> "
			+ "]><poem><line>aaa</line><line num='2'>bbb</line>"
			+ "<line>ccc</line><line num='4'>ddd</line></poem>";

	private static Document document;

	@BeforeClass
	public static void onlyOnce() throws Exception {
		ParserWrapper parserWrapper = ParserWrapper.getParser();
		document = parserWrapper.parseString(xmlFile);
	}

	@Test
	public void checkNode() {
		assertEquals(nodeType, node.getNodeType());
		assertEquals(nodeName, node.getNodeName());
		assertEquals(nodeText, node.getTextContent());
	}

	@Parameters
	public static Collection data() {
		return Arrays.asList(new Object[][] {
				{ 0, Node.DOCUMENT_NODE, "#document", null },
				{ 1, Node.DOCUMENT_TYPE_NODE, "poem", null },
				{ 2, Node.ELEMENT_NODE, "poem", "aaabbbcccddd" },
				{ 3, Node.ELEMENT_NODE, "line", "bbb" },
				{ 4, Node.ATTRIBUTE_NODE, "num", "2" } });
	}

	public static Node getTargetNode(int number) {
		switch (number) {
		case 0:
			return document;
		case 1:
			return document.getFirstChild();
		case 2:
			return document.getChildNodes().item(1);
		case 3:
			return document.getChildNodes().item(1).getChildNodes().item(1);
		case 4:
			return document.getChildNodes().item(1).getChildNodes().item(1)
					.getAttributes().getNamedItem("num");
		default:
			throw new IllegalArgumentException(
					"Only nodes numbered 0..4 can be test targets");
		}
	}
}
