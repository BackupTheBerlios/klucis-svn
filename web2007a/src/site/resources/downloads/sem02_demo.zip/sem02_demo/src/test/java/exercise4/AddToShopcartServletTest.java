package exercise4;

import static org.junit.Assert.assertEquals;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.mock.web.MockRequestDispatcher;

/**
 * TASK: test AddToShopcartServlet using mock.web package from Spring
 */
public class AddToShopcartServletTest {

	Shopcart shopcart;

	AddToShopcartServlet servlet;

	@Before
	public void setUp() {
		// 1. create a Shopcart object and populate it with 5 apples
		shopcart = new Shopcart();
		shopcart.addItem("apple", 5);
		servlet = new AddToShopcartServlet();
	}

	@Test
	public void testAddTwoApples() throws Exception {

		// 2. create a mock object implementing the HttpSession interface
		HttpSession session = new MockHttpSession();

		// 3. configure the mock HttpSession to return your Shopcart object
		// when asked for
		session.setAttribute("shoppingCart", shopcart);

		// 4. create a mock object implementing the HttpServletResponse
		// interface
		HttpServletResponse response = new MockHttpServletResponse();

		// 5. create a mock object implementing the HttpServletRequest interface
		HttpServletRequest request = new MockHttpServletRequest();

		// 6. configure the HttpServletRequest object to return request
		// parameters
		((MockHttpServletRequest) request).addParameter("itemId", "apple");
		((MockHttpServletRequest) request).addParameter("quantity", "2");

		// 7. associate the mock HttpSession object to the mock
		// HttpServletRequest
		((MockHttpServletRequest) request).setSession(session);

		// 8. tell the mock HttpServletRequest to expect a call for
		// getRequestDispatcher("/showCart.jsp") and create a mock
		// RequestDispatcher object to be returned when the servlet
		// asks for it
		MockRequestDispatcher dispatcher = (MockRequestDispatcher) request
				.getRequestDispatcher("/showCart.jsp");
		dispatcher.forward(request, response);

		// 9. initialize and execute the servlet using your mock
		// request/response objects
		servlet.doGet(request, response);

		// 10. verify that the expected number of apples was added to your
		// Shopcart (now it should have 5+2 = 7). 
		assertEquals(7, shopcart.getQuantity("apple"));
	}
}