package exercise6;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import junit.framework.TestCase;

import org.mockejb.MockContainer;
import org.mockejb.SessionBeanDescriptor;
import org.mockejb.jndi.MockContextFactory;

/**
 * 
 */
public class DiscountServiceTest extends TestCase {

    private Item item;

    private MockContainer mockContainer;

    protected void tearDown() throws Exception {
        // after we're done, we should tell MockEJB to return control
        // over JNDI just in case other tests would like to use the real
        // thing...
    }

    protected void setUp() throws Exception {
        // create an Item to be used as the input parameter for
        // getDiscount(Item)

        // give MockEJB full control of the default JNDI context
        // and initialize a MockContainer

        // "deploy" the DiscountService EJB to the MockContainer
    }

    public void testGetDiscount() throws Exception {
        // lookup, create, exercise, assert
    }

    private DiscountServiceHome lookupDiscountServiceHome() throws Exception {
        // get the JNDI context (remember, we've put MockEJB in control by now!)
        
        // do a lookup() for the same JNDI name that you deployed the EJB with

        // narrow() to and return the home interface
        return null;
    }

}