package exercise3;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class PricingMachineWithEasyMockTest extends TestCase {

	private PricingMachine machine;

	private Item item;

	DiscountService mockObject;

	/*
	 * TODO
	 */
	@Before
	public void setUp() {
		ServiceRegistry.removeService("Discounts");
		machine = new PricingMachine();
		item = new Item("Foo", 15.0f);
		// 1. create a mockObject for the DiscountService interface
		// by EasyMock.createMock(SomeAbstractInterface.class)
		mockObject = EasyMock.createMock(DiscountService.class);
		// 2. register our mock object with the ServiceRegistry.registerService
		ServiceRegistry.registerService("Discounts", mockObject);
	}

	@Test
	public void testCalculatingPriceWithDiscountService() throws Exception {

		// 3. record expected interactions and return values (10% discount,
		// i.e. 10.0F is returned for each item )
		// e.g. expect(mock.voteForRemoval("Document")).andReturn((byte) -42);
		EasyMock.expect(mockObject.getDiscount(item)).andReturn(10.0F);

		// 4. switch to replay mode by EasyMock.replay(mockObjectToReplay)
		EasyMock.replay(mockObject);

		// invoke the class under test so that it collaborates with our
		// mock object through the ServiceRegistry
		assertEquals(13.5f, machine.calculatePrice(item), 0.0001f);		
		// The next line should cause failure - an unexpected call to mockObject.getDiscount(foo2)
		// machine.calculatePrice(new Item("Foo2", 15.0f));

		// 5. ask the control to verify that the expected collaboration happened
		// i.e. call EasyMock.verify(mockObjectToVerify)
		EasyMock.verify(mockObject);
	}
}