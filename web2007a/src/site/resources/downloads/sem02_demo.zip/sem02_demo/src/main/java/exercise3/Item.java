package exercise3;

public class Item {

    private float price;

    private String name;

    public Item(String name, float price) {
        this.name = name;
        this.price = price;
    }

    public float getPrice() {
        return this.price;
    }

    public String getName() {
        return this.name;
    }

}