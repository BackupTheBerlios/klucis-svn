package exercise3;

public class PricingMachine {

    public float calculatePrice(Item item) {
        float price = item.getPrice();
        float discountPercentage = 0.0f;
        DiscountService discounts = (DiscountService) ServiceRegistry
                .getService("Discounts");
        if (discounts != null) {
            discountPercentage = discounts.getDiscount(item);
        } else {
            discountPercentage = 0.0f;
        }
        return price * ((100 - discountPercentage) / 100.0f);
    }

}