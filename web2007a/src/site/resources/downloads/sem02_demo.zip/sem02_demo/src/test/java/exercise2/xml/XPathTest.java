package exercise2.xml;

import static org.junit.Assert.assertEquals;

import java.io.StringReader;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.junit.Before;
import org.junit.Test;
import org.w3c.dom.Attr;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class XPathTest {
	private static InputSource inputSource;

	private static XPath xpath = XPathFactory.newInstance().newXPath();

	private static String xmlFile = "<?xml version='1.0'?>"
			+ "<!DOCTYPE poem [ <!ELEMENT poem (line+)> "
			+ "<!ELEMENT line (#PCDATA)><!ATTLIST line num CDATA #IMPLIED> "
			+ "]><poem><line>aaa</line>" + "<line num=\"2\">bbb</line>"
			+ "<line>ccc</line>" + "<line num=\"4\">ddd</line></poem>";

	@Before
	public void setUp() {
		inputSource = new InputSource(new StringReader(xmlFile));
	}

	@Test
	public void testRootElement() throws XPathExpressionException {
		String expression = "/poem";
		NodeList nodes = (NodeList) xpath.evaluate(expression, inputSource,
				XPathConstants.NODESET);
		assertEquals("poem", nodes.item(0).getLocalName());
		assertEquals(1, nodes.getLength());
	}

	@Test
	public void testThirdSibling() throws XPathExpressionException {
		String expression = "//*[3]";
		NodeList nodes = (NodeList) xpath.evaluate(expression, inputSource,
				XPathConstants.NODESET);
		assertEquals(1, nodes.getLength());
		assertEquals("line", nodes.item(0).getLocalName());
		assertEquals("ccc", nodes.item(0).getTextContent());
	}

	@Test
	public void testAttributeValue() throws XPathExpressionException {
		String expression = "//line[@num]";
		NodeList nodes = (NodeList) xpath.evaluate(expression, inputSource,
				XPathConstants.NODESET);
		assertEquals(2, nodes.getLength());
		assertEquals("4", ((Attr) nodes.item(1).getAttributes().getNamedItem(
				"num")).getValue());

	}

	@Test
	public void testAttributeAbsent() throws XPathExpressionException {
		String expression = "//line[not(@num)]";
		NodeList nodes = (NodeList) xpath.evaluate(expression, inputSource,
				XPathConstants.NODESET);
		assertEquals(2, nodes.getLength());
		assertEquals("aaa",nodes.item(0).getTextContent());
		assertEquals("ccc",nodes.item(1).getTextContent());

	}
}
