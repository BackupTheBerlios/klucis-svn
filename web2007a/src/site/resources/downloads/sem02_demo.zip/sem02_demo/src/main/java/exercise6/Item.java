package exercise6;

public class Item {

    private float price;

    private String name;

    public Item(String name, float price) {
        this.name = name;
        this.price = price;
    }

    public float getPrice() {
        return this.price;
    }

    public String getName() {
        return this.name;
    }

    public int hashCode() {
        return new String(getClass().getName() + "-" + name + "-" + price)
                .hashCode();
    }

    public boolean equals(Object obj) {
        if (obj.getClass() == this.getClass()) {
            Item other = (Item) obj;
            return other.name.equals(this.name) && other.price == this.price;
        }
        return false;
    }

    public String toString() {
        return "{Item: name=" + name + ", price=" + price + "}";
    }
}