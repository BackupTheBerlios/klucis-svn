package exercise4;

import java.util.HashMap;
import java.util.Map;

/**
 * A simple Shopcart, which remembers, which items (represented
 * by their itemId:String) have which quantities. Each quantity 
 * is an integer. 
 * We override equals() method to make tests easier - we can 
 * compare with "assertEquals()", if the expected shopcart has
 * been created. 
 */
public class Shopcart {

    private Map<String,Integer> items = new HashMap<String,Integer>();

    public void addItem(String itemId, int quantity) {
        int previousQuantity = getQuantity(itemId);
        items.put(itemId, new Integer(previousQuantity + quantity));
    }

    public int getQuantity(String itemId) {
        Integer quantity = (Integer) items.get(itemId);
        return (quantity != null ? quantity.intValue() : 0);
    }

    public boolean equals(Object o) {
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }
        Shopcart other = (Shopcart) o;
        if (other.items.entrySet().equals(items.entrySet())) {
            return true;
        } else {
            return false;
        }
    }
}