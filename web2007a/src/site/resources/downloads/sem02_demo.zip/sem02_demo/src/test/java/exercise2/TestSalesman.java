package exercise2;

import junit.framework.TestCase;

/**
 * 
 */
public class TestSalesman extends TestCase {

    private Salesman salesman;

    protected void setUp() {
        salesman = new Salesman();
        salesman.setName("Bob");
    }

    public void testSellStuff() {
        assertEquals(5, salesman.sellStuff(4));
    }

    public void testGetName() {
        assertEquals("Bob", salesman.getName());
    }
}