package exercise6;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * 
 */
public interface DiscountServiceHome extends EJBHome {

    public DiscountService create() throws RemoteException, CreateException;

}