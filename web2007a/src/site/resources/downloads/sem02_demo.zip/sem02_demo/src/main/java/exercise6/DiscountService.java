package exercise6;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

public interface DiscountService extends EJBObject {

    public float getDiscount(Item item) throws RemoteException;

}