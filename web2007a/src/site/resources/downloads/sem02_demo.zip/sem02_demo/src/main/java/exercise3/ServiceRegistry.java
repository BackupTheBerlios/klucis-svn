package exercise3;

import java.util.HashMap;
import java.util.Map;

public class ServiceRegistry {

    private static Map<String,Service> SERVICES = new HashMap<String,Service>();

    public static Service getService(String serviceName) {
        return (Service) SERVICES.get(serviceName);
    }

    public static void removeService(String name) {
        SERVICES.remove(name);
    }

    public static void registerService(String name, Service service) {
        SERVICES.put(name, service);
    }

}