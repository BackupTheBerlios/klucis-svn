package exercise6;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBMetaData;
import javax.ejb.Handle;
import javax.ejb.HomeHandle;
import javax.ejb.RemoveException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import junit.framework.TestCase;

import org.easymock.MockControl;
import org.mockejb.MockContainer;
import org.mockejb.SessionBeanDescriptor;
import org.mockejb.jndi.MockContextFactory;

/**
 * 
 */
public class PricingMachineTest extends TestCase {

    private Item item;

    private DiscountService discountServiceMock;

    private MockControl discountServiceControl;

    private MockContainer mockContainer;

    protected void tearDown() throws Exception {
        // after we're done, we should tell MockEJB to return control
        // over JNDI just in case other tests would like to use the real
        // thing...
        MockContextFactory.revertSetAsInitial();
    }

    protected void setUp() throws Exception {
        // create input parameters
        item = new Item("myItem", 100.0f);

        // give MockEJB full control of the default JNDI context
        MockContextFactory.setAsInitial();
        Context ctx = new InitialContext();
        mockContainer = new MockContainer(ctx);

        // obtain a mock implementation of the DiscountService EJB's
        // remote interface -- we don't want to let the EJB under
        // test use the real DiscountServiceBean
        discountServiceControl = MockControl
                .createNiceControl(DiscountService.class);
        discountServiceMock = (DiscountService) discountServiceControl
                .getMock();

        // bind the dependency into the MockContainer's JNDI context
        ctx.bind("ejb/DiscountService", new DiscountServiceHome() {
            // make our mock DiscountServiceHome interface return our mock
            // DiscountService
            public DiscountService create() throws RemoteException,
                    CreateException {
                return discountServiceMock;
            }

            public void remove(Handle handle) throws RemoteException,
                    RemoveException {
            }

            public void remove(Object handle) throws RemoteException,
                    RemoveException {
            }

            public EJBMetaData getEJBMetaData() throws RemoteException {
                return null;
            }

            public HomeHandle getHomeHandle() throws RemoteException {
                return null;
            }
        });

        // "deploy" the EJB we want to test to the MockEJB container
        SessionBeanDescriptor descriptor = new SessionBeanDescriptor(
                "ejb/PricingMachine", PricingMachineHome.class,
                PricingMachine.class, PricingMachineBean.class);
        mockContainer.deploy(descriptor);
    }

    public void testEmptyShopcart() throws Exception {
        // record expected behavior -- PricingMachineBean should ask
        // DiscountService for discounts, which we'll say is 2.5%
        discountServiceMock.getDiscount(item);
        discountServiceControl.setReturnValue(2.5f);

        // switch to replay mode
        discountServiceControl.replay();

        // lookup, create, exercise
        PricingMachineHome home = lookupPricingMachineHome();
        PricingMachine bean = home.create();
        assertEquals(97.5f, bean.calculatePrice(item), 0.001f);

        // verify expected behavior
        discountServiceControl.verify();
    }

    private PricingMachineHome lookupPricingMachineHome() throws Exception {
        // get the JNDI context (remember, we've put MockEJB in control by now!)
        Context rootContext = new InitialContext();
        Object homeAsObject = rootContext.lookup("ejb/PricingMachine");
        Object narrowedHome = PortableRemoteObject.narrow(homeAsObject,
                PricingMachineHome.class);
        return (PricingMachineHome) narrowedHome;
    }

}