package exercise2;

import junit.framework.TestCase;

/**
 * 
 */
public class TestEngineer extends TestCase {

    private Engineer engineer;

    protected void setUp() {
        engineer = new Engineer();
        engineer.setName("Bob");
    }

    public void testBuildStuff() {
        assertEquals("stuff", engineer.buildStuff());
    }

    public void testGetName() {
        assertEquals("Bob", engineer.getName());
    }
}