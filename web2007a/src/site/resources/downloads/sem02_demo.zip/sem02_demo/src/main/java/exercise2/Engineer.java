package exercise2;

public class Engineer extends Employee {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String buildStuff() {
        // this is what engineers do
        return "stuff";
    }
}