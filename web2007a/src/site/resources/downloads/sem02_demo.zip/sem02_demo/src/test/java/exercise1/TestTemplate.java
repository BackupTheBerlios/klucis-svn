package exercise1;

import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.junit.Test;

public class TestTemplate {

	@Test
	public void testNoVariablesAtAll() throws Exception {
		Template template = new Template("This is my simple template");
		assertEquals("This is my simple template", template.evaluate());
	}

	@Test
	public void testSettingOneVariable() throws Exception {
		Template template = new Template("This is my ${foo} template");
		template.set("foo", "simple");
		assertEquals("This is my simple template", template.evaluate());
	}

	@Test
	public void testSettingTwoVariables() throws Exception {
		Template template = new Template("This is my ${foo} ${bar}");
		template.set("foo", "simple");
		template.set("bar", "template");
		assertEquals("This is my simple template", template.evaluate());
	}

	@Test
	public void testSettingNonExistingVariable() throws Exception {
		Template template = new Template("This is my ${foo} ${bar}");
		template.set("abc", "simple");
		template.set("bar", "template");
		assertEquals("This is my ${foo} template", template.evaluate());
	}

	@Test
	public void testEscapingTheDollarCharacter() throws Exception {
		Template template = new Template("This is my \\${foo} template");
		template.set("foo", "simple");
		assertEquals("This is my ${foo} template", template.evaluate());
	}

	@Test
	public void testBackslashBeforeJustSomeCharacter() throws Exception {
		Template template = new Template("This is my \\simple template");
		template.set("foo", "simple");
		assertEquals("This is my \\simple template", template.evaluate());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testBackslashWithinVariable() throws Exception {
		new Template("This is my ${f\\oo} template");
	}
	
	/*
	 * TODO 
	 * Verify that you can have empty variables ${}, and they 
	 * can be mapped to values, if the key "" is set to something.  
	 */
	@Ignore("When the test method is implemented, remove this annotation")
	@Test
	public void testZeroLengthVariableName() throws Exception {
	}


	/*
	 * TODO 
	 * Add test for variables containing a special character '.', 
	 * i.e. check that ${foo.bar} can be replaced with the value
	 * of the key "foo.bar".   
	 */
	@Ignore("When the test method is implemented, remove this annotation")
	@Test
	public void testDotWithinVariable() throws Exception {
	}


	/*
	 * TODO 
	 * Add test for variables containing an illegal special character ',', 
	 * i.e. check that ${foo,bar} causes exception (and either 
	 * catch this exception and fail, if it is not thrown, or 
	 * add the exception's class to the @Test annotation).   
	 */
	@Test
	public void testVariableNameWithIllegalCharacters() throws Exception {
	}

	/**
	 * A template that includes a never-ending variable should cause an
	 * exception to be thrown
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testVariableDoesntEnd() throws Exception {
		new Template("This is my ${f\\oo template");
	}
}