package exercise2.xml;

import java.io.StringReader;

import org.apache.xerces.parsers.DOMParser;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.w3c.dom.Document;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.SAXParseException;

/**
 * This example is adopted Xerces.java class from 
 * the Xerces2 distribution - it only leaves the
 * error handling routines and allows to set a few
 * properties for the parser (related to namespaces
 * and validation). 
 * 
 * It has two methods - "parseUrl()" and "parseString()", 
 * which allow to parse both files with URLs and those
 * XMLs, which are written to a string. It is made
 * for easier debugging (tests are not supposed to depend 
 * on external configuration). 
 * 
 * @author kap
 */
public class ParserWrapper implements ErrorHandler {
	private static DOMParser parser = new DOMParser();

	private static ParserWrapper instance;

	public static ParserWrapper getParser() {
		if (instance == null) {
			instance = new ParserWrapper();
			try {
				parser.setFeature("http://xml.org/sax/features/namespaces",
						true);
				parser.setFeature("http://xml.org/sax/features/validation",
						true);
				parser.setFeature(
						"http://apache.org/xml/features/validation/schema",
						true);
			} catch (SAXException e) {
				e.printStackTrace();
			}
		}
		return instance;
	}

	private ParserWrapper() {
		parser.setErrorHandler(this);

	}

	public void setFeature(String featureId, boolean state)
			throws SAXNotRecognizedException, SAXNotSupportedException {
		parser.setFeature(featureId, state);
	}

	public Document parseUrl(String uri) throws Exception {
		parser.parse(uri);
		return parser.getDocument();
	}

	public Document parseString(String text) throws Exception {
		parser.parse(new XMLInputSource(null, null, null,
				new StringReader(text), null));
		return parser.getDocument();
	}

	public void warning(SAXParseException ex) throws SAXException {
		printError("Warning", ex);
	}

	public void error(SAXParseException ex) throws SAXException {
		printError("Error", ex);
	}

	public void fatalError(SAXParseException ex) throws SAXException {
		printError("Fatal Error", ex);
		throw ex;
	}

	protected void printError(String type, SAXParseException ex) {
		System.err.print("[");
		System.err.print(type);
		System.err.print("] ");
		String systemId = ex.getSystemId();
		if (systemId != null) {
			int index = systemId.lastIndexOf('/');
			if (index != -1)
				systemId = systemId.substring(index + 1);
			System.err.print(systemId);
		}
		System.err.print(':');
		System.err.print(ex.getLineNumber());
		System.err.print(':');
		System.err.print(ex.getColumnNumber());
		System.err.print(": ");
		System.err.print(ex.getMessage());
		System.err.println();
		System.err.flush();
	}

}
