package exercise2;

public abstract class Employee {

}