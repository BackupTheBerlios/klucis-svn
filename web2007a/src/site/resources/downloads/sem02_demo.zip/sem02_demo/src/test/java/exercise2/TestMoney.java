package exercise2;

import junit.framework.TestCase;

public class TestMoney extends TestCase {

    private Money money;
    
    protected void setUp() throws Exception {
        money = new Money();
    }

    public void testMoneyHasAmount() throws Exception {
        money.setAmount(123.45f);
        assertEquals(123.45f, money.getAmount(), 0.000001f);
        money.setAmount(456.78f);
        assertEquals(456.78f, money.getAmount(), 0.000001f);
    }

    public void testMoneyWorksWithTwoDecimals() throws Exception {
        money.setAmount(1234.5678f);
        assertEquals(1234.56f, money.getAmount(), 0.000001f);
    }
    
    public void testMoneyCanBeAdded() throws Exception {
        money.setAmount(12.5f);
        Money anotherMoney = new Money();
        anotherMoney.setAmount(3.45f);
        money.add(anotherMoney);
        assertEquals(15.95f, money.getAmount(), 0.000001f);
    }
}