package exercise1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A simple templating utility which replaces ${variables} within a template
 * text with their values upon template evaluation. Use the backslash character
 * to escape the dollar character if you want to render a string beginning with
 * "${". Allowed characters in a variable's name include all ASCII letters,
 * digits and certain special characters such as ".", ":", "_" and "-".
 */
public class Template {

	private List<Object> tokens;

	private Map<String, String> variableValues;

	private String templateText;

	/**
	 * The default constructor that initializes the template with an "empty"
	 * template text.
	 */
	public Template() {
		this("");
	}

	/**
	 * Initializes the template with the given template text.
	 * 
	 * @param templateText
	 *            The template text with variable placeholders marked with "${"
	 *            and "}" as delimiters.
	 */
	public Template(String templateText) {
		variableValues = new HashMap<String, String>();
		tokens = new ArrayList<Object>();
		load(templateText);
	}

	/**
	 * Loads the given template text.
	 */
	public void load(String templateText) {
		variableValues.clear();
		tokens.clear();
		this.templateText = templateText;
		scanForVariables();
	}

	/**
	 * Sets the value for a given variable.
	 * 
	 * @param variableName
	 *            The variable's name. E.g. "foo" if the template text includes
	 *            a placeholder "${foo}".
	 * @param value
	 *            The value for the variable.
	 */
	public void set(String variableName, Object value) {
		variableValues.put(variableName, String.valueOf(value));
	}

	/**
	 * Evaluates the current template text in the context of the current set of
	 * variables set through {@link set(String, Object) set(String, Object)}.
	 */
	public String evaluate() {
		StringBuffer s = new StringBuffer(templateText.length() * 2);
		for (int i = 0; i < tokens.size(); i++) {
			Object token = tokens.get(i);
			if (token.getClass() == Variable.class) {
				Variable var = (Variable) token;
				String value = (String) variableValues.get(var.name);
				if (value == null) {
					value = "${" + var.name + "}";
				}
				s.append(value);
			} else {
				Text text = (Text) token;
				s.append(text.value);
			}
		}
		return s.toString();
	}

	private void scanForVariables() {
		char[] data = templateText.toCharArray();
		boolean insideVariable = false;
		boolean isEscaping = false;
		StringBuffer token = new StringBuffer();
		for (int i = 0; i < data.length; i++) {
			if (isEscaping) {
				if (data[i] != '$') {
					// only escape the dollar sign, other escape sequences
					// are printed as-is into the output
					token.append('\\');
				}
				token.append(data[i]);
				isEscaping = false;
			} else if (insideVariable) {
				if (data[i] == '}') {
					// variable ends, add the contents of the token as a
					// variable into the token list
					tokens.add(new Variable(token.toString()));
					token.setLength(0);
					insideVariable = false;
				} else {
					token.append(data[i]);
				}
			} else {
				if (beginOfVariable(data, i)) {
					// variable begins, add any data in the token as raw text
					// into the token list
					tokens.add(new Text(token.toString()));
					token.setLength(0);
					insideVariable = true;
					i++; // skip the beginning '{'
				} else if (data[i] == '\\') {
					isEscaping = true;
				} else {
					token.append(data[i]);
				}
			}
		}
		if (insideVariable) {
			throw new IllegalArgumentException("Expected a closing '}'");
		} else if (token.length() > 0) {
			tokens.add(new Text(token.toString()));
		}
	}

	private boolean beginOfVariable(char[] data, int index) {
		if (data[index] == '$') {
			if (index + 1 < data.length) {
				if (data[index + 1] == '{') {
					return true;
				}
			}
		}
		return false;
	}

	private static class Variable {
		public String name;

		public Variable(String name) {
			validateCharacters(name);
			this.name = name;
		}

		private void validateCharacters(String name) {
			char[] chars = name.toCharArray();
			for (int i = 0; i < chars.length; i++) {
				if (!isValidCharacter(chars[i])) {
					throw new IllegalArgumentException("[" + name
							+ "] is not a valid variable name: character "
							+ chars[i] + " is not allowed");
				}
			}
		}

		private boolean isValidCharacter(char c) {
			return new String("abcdefghijklmnopqrstuvwxyz"
					+ "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + ":_-")
					.indexOf(c) != -1;
		}
	}

	private static class Text {
		public String value;

		public Text(String value) {
			this.value = value;
		}
	}

}