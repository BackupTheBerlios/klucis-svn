package exercise3;

public interface DiscountService extends Service {

    public float getDiscount(Item item);

}