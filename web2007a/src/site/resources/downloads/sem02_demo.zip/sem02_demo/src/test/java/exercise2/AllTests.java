package exercise2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * TODO 
 * Pievienot šai anotācijas tā, lai izveidotos 
 * testu virkne (suite), kura izpilda visas testu metodes
 * klasēs <<<TestEngineer>>>, <<<TestMoney>>> un <<<TestSalesman>>>. 
 * 
 * @author kap
 */
public class AllTests {
}
