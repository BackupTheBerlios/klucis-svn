package exercise2;

public class Salesman extends Employee {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int sellStuff(int stuff) {
        // this is what salesmen do
        return stuff + 1;
    }
}