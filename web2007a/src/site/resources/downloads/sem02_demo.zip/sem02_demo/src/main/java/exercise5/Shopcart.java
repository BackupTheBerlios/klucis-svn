package exercise5;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 */
public class Shopcart {

    private Map<String,Integer> items = new HashMap<String,Integer>();

    public void addItem(String itemId, int quantity) {
        int previousQuantity = getQuantity(itemId);
        items.put(itemId, new Integer(previousQuantity + quantity));
    }

    public int getQuantity(String itemId) {
        Integer quantity = items.get(itemId);
        return (quantity != null ? quantity.intValue() : 0);
    }

    public boolean equals(Object o) {
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }
        Shopcart other = (Shopcart) o;
        if (other.items.entrySet().equals(items.entrySet())) {
            return true;
        } else {
            return false;
        }
    }
}