package exercise6;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

public class DiscountServiceBean implements SessionBean {

    private static Map DISCOUNTS = new HashMap() {
        {
            put("apple", new Float(0.0f));
            put("orange", new Float(0.0f));
            put("pear", new Float(5.0f));
            put("beer", new Float(20.0f));
        }
    };

    /**
     * TEST ME!
     */
    public float getDiscount(Item item) {
        Float discountPercent = (Float) DISCOUNTS.get(item.getName());
        return (discountPercent != null ? discountPercent.floatValue() : 0.0f);
    }

    public void setSessionContext(SessionContext ctx) throws EJBException,
            RemoteException {
    }

    public void ejbCreate() throws EJBException, RemoteException {
    }

    public void ejbRemove() throws EJBException, RemoteException {
    }

    public void ejbActivate() throws EJBException, RemoteException {
    }

    public void ejbPassivate() throws EJBException, RemoteException {
    }

}