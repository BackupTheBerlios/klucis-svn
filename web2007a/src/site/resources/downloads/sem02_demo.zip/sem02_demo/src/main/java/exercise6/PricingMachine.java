package exercise6;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

public interface PricingMachine extends EJBObject {
    
    public float calculatePrice(Item item) throws RemoteException;

}