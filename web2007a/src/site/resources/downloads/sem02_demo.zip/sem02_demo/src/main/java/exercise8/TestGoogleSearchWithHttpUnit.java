package exercise8;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;

import junit.framework.AssertionFailedError;

import org.junit.Before;
import org.junit.Test;

import com.meterware.httpunit.GetMethodWebRequest;
import com.meterware.httpunit.SubmitButton;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebLink;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;

/**
 * Google search for Accenture
 */
public class TestGoogleSearchWithHttpUnit {

	private WebResponse frontPage;

	@Before
	public void setUp() throws Exception {
		WebConversation conversation = new WebConversation();
		WebRequest request = new GetMethodWebRequest("http://www.google.com");
		frontPage = conversation.getResponse(request);
	}

	@Test
	public void testFrontPageHasCorrectTitle() throws Exception {
		assertEquals("Google", frontPage.getTitle());
	}

	@Test
	public void testFrontPageHasSearchForm() throws Exception {
		WebForm searchForm = frontPage.getFormWithName("f");
		assertNotNull(searchForm);
		assertArrayContains("q", searchForm.getParameterNames());
		assertArrayContains("btnG", searchForm.getParameterNames());
	}

	@Test
	public void testSearchForAccentureFindsAccentureDotCom() throws Exception {
		WebForm searchForm = frontPage.getFormWithName("f");
		searchForm.setParameter("q", "Accenture");
		SubmitButton submitButton = getButtonWithName(searchForm, "btnG");
		WebResponse searchResults = searchForm.submit(submitButton);
		WebLink[] links = searchResults.getLinks();
		Set<String> linkUrls = new HashSet<String>();
		for (int i = 0; i < links.length; i++) {
			linkUrls.add(links[i].getURLString());
		}
		assertTrue(linkUrls.contains("http://www.accenture.com/"));
	}

	@Test
	public void testSearchResultsPageRemembersQuery() throws Exception {
		WebForm searchForm = frontPage.getFormWithName("f");
		searchForm.setParameter("q", "accenture");
		SubmitButton submitButton = getButtonWithName(searchForm, "btnG");
		WebResponse searchResults = searchForm.submit(submitButton);
		searchForm = searchResults.getFormWithName("gs");
		assertEquals("accenture", searchForm.getParameterValue("q"));
	}

	// helper methods:

	private SubmitButton getButtonWithName(WebForm form, String name) {
		SubmitButton[] buttons = form.getSubmitButtons();
		for (int i = 0; i < buttons.length; i++) {
			if (buttons[i].getName().equals(name)) {
				return buttons[i];
			}
		}
		return null;

	}

	protected void assertArrayContains(Object expectedValue, Object[] array) {
		for (int i = 0; i < array.length; i++) {
			if (array[i].equals(expectedValue)) {
				return;
			}
		}
		throw new AssertionFailedError("<" + expectedValue + "> not found in <"
				+ arrayToString(array) + ">");
	}

	private String arrayToString(Object[] array) {
		StringBuffer s = new StringBuffer();
		s.append("[");
		for (int i = 0; i < array.length; i++) {
			if (i != 0) {
				s.append(", ");
			}
			s.append(array[i]);
		}
		s.append("]");
		return s.toString();
	}

}