package exercise6;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

public class PricingMachineBean implements SessionBean {

    public float calculatePrice(Item item) throws RemoteException {
        try {
            float price = item.getPrice();
            float discountPercentage = 0.0f;
            DiscountService discounts = lookupDiscountService();
            if (discounts != null) {
                discountPercentage = discounts.getDiscount(item);
            } else {
                discountPercentage = 0.0f;
            }
            return price * ((100 - discountPercentage) / 100.0f);
        } catch (Exception e) {
            throw new RemoteException("Error", e);
        }
    }

    private DiscountService lookupDiscountService() throws NamingException,
            RemoteException, CreateException {
        Context ctx = new InitialContext();
        Object obj = ctx.lookup("ejb/DiscountService");
        DiscountServiceHome home = (DiscountServiceHome) PortableRemoteObject
                .narrow(obj, DiscountServiceHome.class);
        return home.create();
    }

    public void setSessionContext(SessionContext ctx) throws EJBException,
            RemoteException {
    }

    public void ejbCreate() throws CreateException {
    }

    public void ejbRemove() throws EJBException, RemoteException {
    }

    public void ejbActivate() throws EJBException, RemoteException {
    }

    public void ejbPassivate() throws EJBException, RemoteException {
    }

}