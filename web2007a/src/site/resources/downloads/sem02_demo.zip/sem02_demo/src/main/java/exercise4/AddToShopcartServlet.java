package exercise4;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 */
@SuppressWarnings("serial")
public class AddToShopcartServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        // obtain the shopping cart (or create one if we don't have one yet)
        HttpSession session = request.getSession();
        Shopcart shopcart = (Shopcart) session.getAttribute("shoppingCart");
        if (shopcart == null) {
            shopcart = new Shopcart();
            session.setAttribute("shoppingCart", shopcart);
        }

        // figure out what to do and do it
        String itemId = request.getParameter("itemId");
        String quantity = request.getParameter("quantity");
        shopcart.addItem(itemId, Integer.parseInt(quantity));

        // forward to a JSP for rendering the response
        RequestDispatcher rd = request.getRequestDispatcher("/showCart.jsp");
        rd.forward(request, response);
    }
}