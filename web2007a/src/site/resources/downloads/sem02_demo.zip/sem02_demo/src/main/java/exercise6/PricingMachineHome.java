package exercise6;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public interface PricingMachineHome extends EJBHome {

    public PricingMachine create() throws RemoteException, CreateException;
}