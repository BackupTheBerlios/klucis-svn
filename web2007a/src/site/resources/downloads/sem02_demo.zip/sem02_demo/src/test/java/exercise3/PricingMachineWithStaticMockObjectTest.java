package exercise3;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * This test is intended as comparison for the
 * EasyMock test - in this case DiscountService interface
 * is so simple that mock object can be created by a 
 * simple anonymous class. 
 * 
 * @author lasse.koskela
 */
public class PricingMachineWithStaticMockObjectTest {

    private PricingMachine machine;

    private Item item;

    @Before
    public void setUp() {
        ServiceRegistry.removeService("Discounts");
        machine = new PricingMachine();
        item = new Item("Foo", 15.0F);
    }

    @Test
    public void testCalculatingPriceWithDiscountService() throws Exception {
        ServiceRegistry.registerService("Discounts", new DiscountService() {
            public float getDiscount(Item item) {
                return 10.0f;
            }
        });
        assertEquals(13.5f, machine.calculatePrice(item), 0.0001f);
    }

    @Test
    public void testCalculatingPriceWithoutDiscountService() throws Exception {
        assertEquals(15.0f, machine.calculatePrice(item), 0.0001f);
    }
}