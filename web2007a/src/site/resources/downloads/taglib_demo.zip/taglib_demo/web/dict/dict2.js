var click_block=0
var IE=(navigator.appName=='Microsoft Internet Explorer'?1:0);

function dictionary() {
if (click_block) {
click_block=0
return
}

if (!IE) {
t = document.getSelection();
opennewdictwin(t);
}
else {
t = document.selection.createRange();
if(document.selection.type == 'Text' && t.text != '') {
document.selection.empty();
opennewdictwin(t.text);
      }
   }
}
function opennewdictwin(text) {
while (text.substr(text.length-1,1)==' ') 
	text=text.substr(0,text.length-1)
while (text.substr(0,1)==' ') 
	text=text.substr(1)
if (text > '') {
document.location='http://www.thefreedictionary.com/'+escape(text);
   }
}
var discl_state=1;
function toggle() {
	if (IE) if (discl_state) 
	{
	div_discl.style.display='none';
	img_discl.src='http://img.thefreedictionary.com/toggle/pluscold.gif'	
	discl_state=0;
	}
	else
	{
	div_discl.style.display='';
	img_discl.src='http://img.thefreedictionary.com/toggle/minuscold.gif'
	discl_state=1;
	}
}

function wiki(word) {
document.write('<div style="font-size: 10px;FONT-FAMILY: Tahoma;margin-top:5px">This article was derived fully or in part from an <a target=_blank href="http://en.wikipedia.org/wiki/'+escape(word)+'">article on Wikipedia.org</a> - the free encyclopedia created and edited by online user community. The text was not checked or edited by anyone on our staff. Although the vast majority of the wikipedia encyclopedia articles provide accurate and timely information please do not assume the accuracy of any particular article. '+ 
	'This article is distributed under the terms of <a href="http://encyclopedia.thefreedictionary.com/GNU%20Free%20Documentation%20License">GNU Free Documentation License</a>.</div><br>')
}
function foldoc(){
document.write('<div style="font-size: 10pt;FONT-FAMILY: Arial;margin-top:5px">This article is provided by FOLDOC - Free Online Dictionary of Computing (<a target=_blank href="http://www.foldoc.org">www.foldoc.org</a>)</div><br>')
}
function hm(){
document.write('<div style="font-size: 10px;FONT-FAMILY: Arial;margin-top:5px;text-align:right;color:gray"><u>The American Heritage� Dictionary of the English Language, Fourth Edition</u> copyright &copy;2000 by <a style="color:gray;text-decoration:none" target=_blank href="http://www.eref-trade.hmco.com/">Houghton Mifflin Company</a>.<br>Updated in 2003. Published by <a style="color:gray;text-decoration:none" target=_blank href="http://www.eref-trade.hmco.com/">Houghton Mifflin Company</a>. All rights reserved.</div>')
}
function layer(id){
  var res
  if(document.getElementById) res=document.getElementById(id)
  if(document.all) res=document.all[id]
  if (res) return res.style
  return null
}

var nsx;
var nsy;
if (!document.all) {
	document.captureEvents(Event.MOUSEMOVE);	
	document.onmousemove=get_mouse;
}
function get_mouse(e) {
	nsx=e.pageX-10;
	nsy=e.pageY+5;
}
function t_i(id) {
	var hlp=layer('Tp'+id)
	if (hlp) {
	if (document.all) {
	 nsy=event.y+document.body.scrollTop
	 nsx=event.x+document.body.scrollLeft
	}
	hlp.top=nsy+20
	hlp.left=(nsx>610?nsx-470:140)		
	hlp.visibility='visible'
}}
function t_o(id) {
	var hlp=layer('Tp'+id)
	if(hlp) hlp.visibility='hidden'
}
function el(a){
window.open('http://'+a, '_blank')
return false
}
function setcolor(color) {
return;
if (Ov2)
for (i in Ov.all)
if(Ov.all[i].tagName=='A') {
Ov.all[i].style.color=color
Ov2.all[i].style.color=color
}}
function blink(i) {
return;
if (i) {
setcolor('#0000FF');
window.setTimeout('blink(0)',100);
}
else{
setcolor('#0000CF');
window.setTimeout('blink(1)',100);
}}
function eml2(path, name){
open('/_/viewer.aspx?path='+escape(path)+'&name='+name,'img','');
}
function eml(path, name){
location='/_/viewer.aspx?path='+escape(path)+'&name='+name,'view';
}
function openerlink(link) {
opener.location='http://encyclopedia.thefreedictionary.com/'+link;
self.close()
return false;
}
function google_ad_request_done(google_ads) {
  var i=0;
  for (i=0;i<google_ads.length && i<3;i++){
    var ad=google_ads[i]
    if (i==0) document.write('<span style="float:right">Ads by Goooooogle</span>')
    document.write('<a href="'+ad.url+'" onMouseOver="return m_over(\'go to '+ad.visible_url+'\')" onMouseOut="m_out()">')
    document.write('<div class=OvTitle>'+ad.line1+'</div>')
    document.write('<div class=OvDescr><font color=Black>'+ad.line2+' '+ad.line3+'</font>')
    document.write('<div class=OvURL><font color=Green>'+ad.visible_url+'</font></div></div></a>')
  }
  if (i==0)
  	 document.write('<iframe src="http://www.thefreedictionary.com/_/deftopad.aspx" border=0 frameborder=0 width=728 height=90 scrolling=no></iframe><br>')
}
function m_over(url){
window.status=url;
return true;
}
function m_out(){
window.status = '';
}
function endPlay(){
sound_frame.document.location='about:blank';
}

function play(File) {
if (IE) {
  var sf=sound_frame.document;
  sf.write('<html><head><bgsound src="http://img.thefreedictionary.com/hm/prons/'+File+'.wav"><\/head><\/html>');    
  sf.close();
  window.onblur=endPlay;
} else
  location=('http://img.thefreedictionary.com/hm/prons/'+File+'.wav');
window.status='';
}

function pron_key(t) {
var pkw=open('/_/pk.htm','pk','width=630,height=675,statusbar=0,menubar=0');
return false;
}