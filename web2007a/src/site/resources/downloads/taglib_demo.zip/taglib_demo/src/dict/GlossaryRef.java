package dict;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

@SuppressWarnings("serial")
public class GlossaryRef extends TagSupport {
	private String term; 
	public void setTerm(String t) {
		term = t; 
	}
	public int doStartTag() {
		JspWriter out = pageContext.getOut();
		try {
			out.println("[starttag term = " + term + "]"); 
		}
		catch (Exception e) {
			System.out.println("[exception in doStartTag: " + e + "]"); 
		}
		return EVAL_BODY_INCLUDE;
	}

	public int doEndTag() {
		JspWriter out = pageContext.getOut();
		try {
			out.println("[endtag]"); 
		}
		catch (Exception e) {
			System.out.println("[exception in doStartTag: " + e + "]"); 
		}
		return EVAL_PAGE;		
	}

}

