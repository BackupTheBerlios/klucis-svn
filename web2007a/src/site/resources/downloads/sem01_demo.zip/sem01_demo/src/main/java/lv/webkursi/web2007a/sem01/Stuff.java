package lv.webkursi.web2007a.sem01;

import java.util.HashMap;
import java.util.Map;

public class Stuff {
	public static void main(String[] args) {
		Map<String,Integer> map = new HashMap<String,Integer>();
		int stuff = map.get("");
		System.out.println("Stuff = " + stuff);
	}

}
