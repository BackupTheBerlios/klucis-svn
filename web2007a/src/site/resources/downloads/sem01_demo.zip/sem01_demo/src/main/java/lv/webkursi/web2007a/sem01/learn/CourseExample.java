package lv.webkursi.web2007a.sem01.learn;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@Learn(value="You can learn a lot from this class")
public class CourseExample extends HttpServlet {
	@Learn(value="This is a encapsulated field, but accessible to child classes as well")
	protected String message = "Hello";


	@Learn(value="Just a no-argument constructor; useful as a bean")
	protected CourseExample() {
		super();
	}

	@Learn(value="The payload - value to be displayed")
	private String doSomethingInteresting() {
		return message;
	}

	private void thisMethodHasNoInstructionalValue() {
	}
	
	@Learn(value="GET method displays something")
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		doPost(request,response);
	}

	@Learn(value="Support also a POST method", moduleId="3",
	           moduleOnly=true)
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();
		thisMethodHasNoInstructionalValue();
		out.println(doSomethingInteresting());
	}
}
