package lv.webkursi.web2007a.sem01;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * This JUnit test just demonstrates JUnit annotations and the order of
 * execution.
 * 
 * @author kap
 */
@RunWith(Suite.class)
@Suite.SuiteClasses(value = { KlaseTest.KlaseInner1.class, KlaseTest.KlaseInner2.class })
public class KlaseTest {

	public static class KlaseInner1 {

		@Before
		public void setUp() {
			System.out.println("setUp()");
		}

		@After
		public void tearDown() {
			System.out.println("tearDown()");
		}

		@Test
		public void testSomething() {
			System.out.println("testSomething()");
		}

		@Test
		public void testSomethingElse() {
			System.out.println("testSomethingElse()");
		}

		@Test(expected = RuntimeException.class)
		public void testSomeException() {
			System.out.println("testSomeException()");
			System.out.println(1 / 0);
		}

		@Ignore(value = "Test method not ready")
		@Test
		public void ignoredTestCase() {
			System.out.println("ignoredTestCase()");
		}
	}

	public static class KlaseInner2 {
		@Test
		public void verySimpleTest() {
			System.out.println("verySimpleTest()");
		}
	}
}
