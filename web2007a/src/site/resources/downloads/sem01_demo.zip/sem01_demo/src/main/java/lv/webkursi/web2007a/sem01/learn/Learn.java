package lv.webkursi.web2007a.sem01.learn;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * This package contains example from chapter 21 in this book: "Java Enterprise
 * in a Nutshell, 3rd Edition" by William Crawford, Jim Farley, Publisher:
 * O'Reilly, Pub Date: November 2005, ISBN: 0-596-10142-2, Pages: 892
 */
@Target( { ElementType.TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR,
		ElementType.FIELD }) // also LOCAL_VARIABLE, PACKAGE, PARAMETER
@Retention(RetentionPolicy.RUNTIME)
public @interface Learn {
	String value(  );
	String moduleId(  ) default "*";
    boolean moduleOnly(  ) default false;
}
