package lv.webkursi.web2007a.sem01.learn;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class LearnProcessor {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		if (args.length < 1) {
			System.err
					.println("USAGE: java LearnProcessor fully-specified-class-name");
			System.exit(1);
		}
		String targetClassname = args[0];
		try {
			// Look up the class provided in the arguments
			Class targetClass = Class.forName(targetClassname);
			// Output the page header and start the table structure.
			// If the class is annotated with a Learn tag, include the
			// notation in the table as well.
			if (targetClass.isAnnotationPresent(Learn.class)) {
				Learn annot = (Learn) targetClass.getAnnotation(Learn.class);
				outputHeader(targetClass, annot.value());
			} else {
				outputHeader(targetClass, null);
			}
			// Check each member variable on the class, and output
			// any notations found
			Field[] fields = targetClass.getDeclaredFields();
			for (int i = 0; i < fields.length; i++) {
				if (fields[i].isAnnotationPresent(Learn.class)) {
					Learn annot = (Learn) fields[i].getAnnotation(Learn.class);
					outputFieldNotation(fields[i], annot.value());
				}
			}
			// Check each constructor on the class, and output a notation
			// for any that have a Learn annotation
			Constructor[] cons = targetClass.getConstructors();
			for (int i = 0; i < cons.length; i++) {
				if (cons[i].isAnnotationPresent(Learn.class)) {
					Learn annot = (Learn) cons[i].getAnnotation(Learn.class);
					outputConstructorNotation(cons[i], annot.value());
				}
			}
			// Check each method on the class, and output a notation
			// for any methods that have a Learn annotation
			Method[] methods = targetClass.getMethods();
			for (int i = 0; i < methods.length; i++) {
				if (methods[i].isAnnotationPresent(Learn.class)) {
					Learn annot = (Learn) methods[i].getAnnotation(Learn.class);
					outputMethodNotation(methods[i], annot.value());
				}
			}
			// Print the page footer
			outputFooter(targetClass);
		} catch (ClassNotFoundException cnfe) {
			System.err.println("Class \"" + targetClassname + "\" not found");
		}
	}

	public static void outputHeader(Class clazz, String value) {
		System.out.println("<html><body>");
		System.out.println("<center><large><code>" + clazz.getName() + "</code>, " + value + "</large></center>");
		System.out.println("<table border=\"1\" cellspcing=\"0\">");

	}

	public static void outputFooter(Class clazz) {
		System.out.println("</body></html>");
	}

	public static void outputFieldNotation(Field field, String value) {
		System.out.println("<tr><td><b>Field:</b><br />");
		String modifierString = buildModifierString(field.getModifiers());		
		System.out.println("<code>" + modifierString
				+ field.getName() + "</code>");
		System.out.println("</td></tr>");
	}

	public static void outputConstructorNotation(Constructor cons, String value) {
		System.out.println("<tr><td><b>Constructor:</b><br />");
		String modifierString = buildModifierString(cons.getModifiers());
		System.out.println("<code>" + modifierString 
				+ cons.getClass().getName() + "("
				+ concatParameterTypes(cons.getParameterTypes()) + ")</code>");
		System.out.println("</td></tr>");
	}

	public static void outputMethodNotation(Method method, String value) {
		System.out.println("<tr><td><b>Method:</b><br />");
		String modifierString = buildModifierString(method.getModifiers());
		System.out
				.println("<code>" + modifierString
						+ method.getName() + "("
						+ concatParameterTypes(method.getParameterTypes())
						+ ")</code>");
		System.out.println("</td></tr>");
	}

	public static String concatParameterTypes(Class[] paramTypes) {
		StringBuffer result = new StringBuffer();
		for (int i = 0; i < paramTypes.length; i++) {
			result.append(paramTypes[i].getName());
			if (i < paramTypes.length - 1) {
				result.append(",");
			}
		}
		return result.toString();
	}
	
	public static String buildModifierString(int mod) {
		StringBuffer result = new StringBuffer();
		if (Modifier.isAbstract(mod)) {
			result.append("abstract ");
		}
		if (Modifier.isFinal(mod)) {
			result.append("final ");
		}
		if (Modifier.isNative(mod)) {
			result.append("native ");
		}
		if (Modifier.isSynchronized(mod)) {
			result.append("synchronized ");
		}
		if (Modifier.isTransient(mod)) {
			result.append("transient ");
		}
		if (Modifier.isVolatile(mod)) {
			result.append("volatile ");
		}
		if (Modifier.isPrivate(mod)) {
			result.append("private ");
		}
		if (Modifier.isProtected(mod)) {
			result.append("protected ");
		}
		if (Modifier.isPublic(mod)) {
			result.append("public ");
		}
		return result.toString();
	}
}
