package datespackage;

import java.util.Calendar;
import java.util.GregorianCalendar;

//import javax.jws.WebService;

//@WebService(name = "GetDatesWS", serviceName = "GetDatesWS")
public class GetDates {
    public GetDates() {
    }

    public Calendar getDate() {
        return Calendar.getInstance();
    }

    /**
     * @param daysHence
     * @return
     */
    public Calendar getDateHence(Integer daysHence) {
        GregorianCalendar myCalendar = new GregorianCalendar();
        myCalendar.add(GregorianCalendar.DATE, daysHence);
        return myCalendar;
    }
}
