package client;

import java.util.Calendar;

import javax.xml.namespace.QName;

import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.rpc.client.RPCServiceClient;

//import sample.pojo.data.Weather;


public class GetDatesRPCClient {

    public static void main(String[] args1) throws AxisFault {

        RPCServiceClient serviceClient = new RPCServiceClient();

        Options options = serviceClient.getOptions();

        EndpointReference targetEPR = new EndpointReference("http://localhost:7080/axis2/services/GetDatesWS");

        options.setTo(targetEPR);

        QName opGetDate = new QName("http://service.pojo.sample/xsd", "getDate");

        Object[] opGetDateArgs = new Object[] { };
        Class[] returnTypes = new Class[] { Calendar.class };
        
        
        Object[] response = serviceClient.invokeBlocking(opGetDate,
                opGetDateArgs, returnTypes);
        
        Calendar result = (Calendar) response[0];
        
        if (result == null) {
            System.out.println("Calendar didn't initialize!");
            return;
        }
        
        System.out.println("Date now is : " + result);
        
        /*
        QName opGetDateHence = new QName("http://service.pojo.sample/xsd", "getDateHence");

        Object[] opGetDateHenceArgs = new Object[] { 5 };
        Class[] returnTypes2 = new Class[] { Calendar.class };


        Object[] response2 = serviceClient.invokeBlocking(opGetDateHence, opGetDateHenceArgs, returnTypes2);
        Calendar result2 = (Calendar)response2[0];
        
        System.out.println("In 5 days the date will be: " + result);
        */
        
    }
}
