  62,696 easymock.jar
 112,249 junit-4.1.jar
  97,693 servlet-api.jar
  92,347 spring-mock.jar