package lv.webkursi.web2007a.sem05.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.QuerySolutionMap;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.util.StringUtils;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.RDFNode;

/**
 * This example is adopted from 
 * http://seaborne.blogspot.com/2006/05/parameterized-queries_07.html
 * 
 * @author kap
 */
public class ParametrizedSparqlDemo {
	public static void main(String[] args) throws IOException {
		InputStream in = new FileInputStream(new File(
				"src/main/resources/test.n3"));
		Model model = ModelFactory.createMemModelMaker().createDefaultModel();
		
		Model model2 = ModelFactory.createMemModelMaker().createDefaultModel();
		
		model.read(in, null, "N3");
		in.close();

		String queryString = StringUtils.join("\n", new String[] {
				"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>",
				"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>",
				"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>",
				"PREFIX we: <http://www.hpl.hp.com/schema/20061103/whatever#>",
				"PREFIX : <http://example.com/portal#>",
				"SELECT ?title ?credits ?professor", "WHERE {",
				//"?x :title $courseTitle;",
				"?x :url $courseUrl;",
				"  :courses ?y.",
				"# rdfs:member is a super-property of rdf:_1, rdf:_2, etc.",
				"?y rdfs:member ?z.", "?z we:title ?title;",
				"  we:credits ?credits;", "  we:professor ?professor", "}" });

		QuerySolutionMap initialSettings = new QuerySolutionMap();
		//RDFNode node = model2.createLiteral("Various Sciences");
		RDFNode node = model2.createResource("http://www.lu.lv/fakultates/tf/index.html");
		//initialSettings.add("courseTitle", node);
		initialSettings.add("courseUrl", node);
				
		QueryExecution qexec = QueryExecutionFactory.create(queryString, model,
				initialSettings);

		try {
			ResultSet results = qexec.execSelect();
			while (results.hasNext()) {
				QuerySolution soln = results.nextSolution();
				String title = soln.getLiteral("title").getString();
				int credits = soln.getLiteral("credits").getInt();
				String professor = soln.getLiteral("professor").getString();

				System.out.println("<tr><td>" + title + "</td><td>" + credits
						+ "</td><td>" + professor + "</td></tr>");
			}
		} finally {
			qexec.close();
		}
	}
}
