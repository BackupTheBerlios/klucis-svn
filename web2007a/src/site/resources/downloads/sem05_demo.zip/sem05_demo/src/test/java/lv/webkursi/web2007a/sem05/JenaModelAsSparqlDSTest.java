package lv.webkursi.web2007a.sem05;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.springframework.mock.web.MockHttpServletRequest;

import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;

/**
 * @author kap
 */
@RunWith(Suite.class)
@Suite.SuiteClasses(value = { JenaModelAsSparqlDSTest.SpecialCases.class
		})
public class JenaModelAsSparqlDSTest {

	private static final String fullClassName = JenaModelAsSparqlDSTest.class
			.getName();

//	private static MockDescriptionFactory descriptionFactory = MockDescriptionFactory.getInstance();


	public static class SpecialCases {
		@Test
		public void query() {
			Model model = ModelFactory.createDefaultModel();
			model.createResource().addProperty(RDFS.label, "r1");
			model.createResource().addProperty(RDFS.label, "r2");
			JenaModelAsSparqlDS sparqlDS = new JenaModelAsSparqlDS();
			sparqlDS.setModel(model);
			QueryExecution q = sparqlDS
					.query("PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> \n"
							+ "SELECT ?object \n"
							+ "WHERE {?subject rdfs:label ?object}");
			ResultSet rs = q.execSelect();
			int count = 0;
			while (rs.hasNext()) {
				QuerySolution s = rs.nextSolution();
				Literal l = s.getLiteral("object");
				assertTrue(l.toString().equals("r1")
						|| l.toString().equals("r2"));
				count++;
			}
			assertTrue(count == 2);
			q.close();
		}

		@Test
		public void factory() {
			Model model = ModelFactory.createDefaultModel();
			Resource file = model
					.createResource("file:src/test/resources/" + fullClassName + "/test.n3");
			
			/*
			Resource jmd = model.createResource().addProperty(RDF.type,
					PORTAL.JenaFileModel).addProperty(PORTAL.file, file);
			Resource dsd = model.createResource().addProperty(RDF.type,
					PORTAL.JenaModelAsSparqlDS).addProperty(PORTAL.hasSource,
					jmd);
			*/
			/*
			ComponentFactoryCatalog fc = new MockComponentFactoryCatalog()
					.getCatalog();

			JenaModelAsSparqlDS ds = (JenaModelAsSparqlDS) componentManager
					.getStaticComponent(dsd);
					*/
			JenaModelAsSparqlDS ds = new JenaModelAsSparqlDS();

			QueryExecution q = ds
					.query("PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> \n"
							+ "SELECT ?object \n"
							+ "WHERE {?subject rdfs:label ?object}");
			ResultSet rs = q.execSelect();
			int count = 0;
			while (rs.hasNext()) {
				QuerySolution s = rs.nextSolution();
				Literal l = s.getLiteral("object");
				assertTrue(l.toString().equals("JenaModelAsSparqlDS-r3")
						|| l.toString().equals("JenaModelAsSparqlDS-r4"));
				count++;
			}
			assertTrue(count == 2);
			q.close();
		}
	}
}
