package lv.webkursi.web2007a.sem05;

import java.util.HashMap;
import java.util.Map;

import com.hp.hpl.jena.rdf.model.ResIterator;

/**
 * Determine a resource list from SPARQL query.
 * 
 * <p>
 * This class runs a SPARQL query and can return an iterator over the list of
 * resources selected by a variable in the query. The default variable is named
 * <code>result</code> but this can be overridden using the the
 * setResultVariableName method.
 * </p>
 * 
 * <p>
 * The component is configured not with a whole SPARQL query, but just with the
 * expression that is used to select the results.
 * </p>
 */
public class SparqlFindResources implements ResourceIteratorSource {

	protected String prefixes;

	protected String selectExpression;

	protected String substitutedSelectExpression;

	protected String resultVariableName = "result";

	protected SparqlDataSource dataSource;

	protected long limit = -1;

	protected long offset = 0;

	protected String orderBy = null;

	protected boolean ascending = true;

	protected Map<String, Object> paramMap = new HashMap<String, Object>();

	public Map<String, Object> getParamMap() {
		return paramMap;
	}

	public void setParamMap(Map<String, Object> paramMap) {
		this.paramMap = paramMap;
	}

	/**
	 * Set the name of the variable which identifies the list of results to
	 * return.
	 * 
	 * @param resultVariableName
	 *            the name of the result variable.
	 */

	public void setResultVariableName(String resultVariableName) {
		this.resultVariableName = resultVariableName;
	}

	/**
	 * Return an iterator over the resources selected by the query.
	 * 
	 * @return an iterator over the resources selected by the query.
	 * 
	 * <p>
	 * <b>Contract</b>
	 * </p>
	 * <ol>
	 * <li>The iterator returns a resource corresponding to every match of the
	 * resultVariableName in the query result set.</li>
	 * 
	 * <li>Each resource is returned only once.</li>
	 * 
	 * <li>If no results are found then an iterator which returns no resources
	 * is returned.</li>
	 * 
	 * <li>If the variable name resultVariableName does not appear in the
	 * result set a PortalConfigurationException is returned.</li>
	 * 
	 * <li>Each resource can be queried to retrieve its properties.</li>
	 * 
	 * <li>If <code>sortBy</code> is not null, resources are returned ordered
	 * by the value of the <code>orderBy</code> property.</li>
	 * 
	 * <li>The ordering is ascending unless the <code>ascending</code>
	 * attribute is false.</li>
	 * 
	 * <li>If the <code>limit</code> attribute is greater than or equal to
	 * zero, then at most <code>limit</code> results are returned.</li>
	 * 
	 * <li>If <code>sortBy</code> is not null then the results returned start
	 * at the result <code>offset</code> + 1.</li>
	 * 
	 * <li>If <code>offset</code> is greater than 0 and <code>sortBy</code>
	 * is null, than a PortalConfigurationException is thrown.</li>
	 * 
	 * <li>If <code>ascending</code> is false, then the sort order is
	 * descending</li>
	 * </ol>
	 */
	public ResIterator getResultsIterator() {
		QueryTemplate template = new QueryTemplate(dataSource);
		template.setAscending(ascending);
		template.setLimit(limit);
		template.setOffset(offset);
		template.setOrderBy(orderBy);
		template.setPrefixes(prefixes);
		template.setResultVariableName(resultVariableName);
		return template.queryForIterator(selectExpression, paramMap);
	}

	/**
	 * @return Returns the dataSource.
	 */
	public SparqlDataSource getDataSource() {
		return dataSource;
	}

	/**
	 * @param dataSource
	 *            The dataSource to set.
	 */
	public void setDataSource(SparqlDataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * @return Returns the limit.
	 */
	public long getLimit() {
		return limit;
	}

	/**
	 * @param limit
	 *            The limit to set.
	 */
	public void setLimit(long limit) {
		this.limit = limit;
	}

	/**
	 * @return Returns the offset.
	 */
	public long getOffset() {
		return offset;
	}

	/**
	 * @param offset
	 *            The offset to set.
	 */
	public void setOffset(long offset) {
		this.offset = offset;
	}

	/**
	 * @return Returns the orderBy.
	 */
	public String getOrderBy() {
		return orderBy;
	}

	/**
	 * @param orderBy
	 *            The orderBy to set.
	 */
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	/**
	 * @return Returns the resultVariableName.
	 */
	public String getResultVariableName() {
		return resultVariableName;
	}

	/**
	 * Set the selectExpression for this component.
	 * 
	 * @param selectExpression
	 */
	public void setSelectExpression(String selectExpression) {
		this.selectExpression = selectExpression;
	}

	/**
	 * @return Returns the selectExpression.
	 */
	public String getSelectExpression() {
		return selectExpression;
	}

	/**
	 * @return the selectExpression, where all ${...} placeholders are replaced
	 *         by http request's values
	 */
	public String getSubstitutedSelectExpression() {
		return substitutedSelectExpression;
	}

	/**
	 * @return Returns the ascending.
	 */
	public boolean isAscending() {
		return ascending;
	}

	/**
	 * @param ascending
	 *            The ascending to set.
	 */
	public void setAscending(boolean ascending) {
		this.ascending = ascending;
	}

	/**
	 * @return the prefixes
	 */
	public String getPrefixes() {
		return prefixes;
	}

	/**
	 * @param prefixes
	 *            the prefixes to set
	 */
	public void setPrefixes(String prefixes) {
		this.prefixes = prefixes;
	}
}