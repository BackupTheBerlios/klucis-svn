package lv.webkursi.web2007a.sem05.facet;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import lv.webkursi.web2007a.sem05.AbstractComponent;
import lv.webkursi.web2007a.sem05.data.RDFUtil;


/**
 * A Facet which filters results based on a property value where that value is a
 * node in a hierarchy.
 * 
 * @author bwm
 * 
 */
public class HierarchicalPropertyFacet extends AbstractComponent implements
		Facet {

	// some of these might move to an abstract facet class
	protected Property property; // the property the facet filters on
	
	protected String viewName;

	protected Property hasParentProperty;

	protected Property hasChildProperty;
	
	protected Resource rootConcept;

	protected Model ontology;

	protected String label;

	/**
	 * Lookup the ontology to find the label associated with r
	 * the label is the rdfs:label of the property but be careful of language
	 * variants this will need to be local aware at some point but I'm ignoring
	 * that for now. I'm not sure if its worth caching the labels Lets not for
	 * now - its an optimization that can be none later. (I'm wondering that
	 * this is shared functionality with SimplePropertyFacet so it might be
	 * worth factoring this out into a common abstract base class.)
	 * 
	 * @param r
	 */
	public void getLabel(Resource r) {
		label = RDFUtil.getLabel(r);
	}

	/**
	 * @return the property
	 */
	public Property getProperty() {
		return property;
	}

	/**
	 * @param property
	 *            the property to set
	 */
	public void setProperty(Property property) {
		this.property = property;
	}

	/**
	 * @param ontology
	 *            the ontology to set
	 */
	public void setOntology(Model ontology) {
		this.ontology = ontology;
	}

	/**
	 * Create a new HierarchicalPropertyFacetState; give it the
	 * same ID as this component but with a "." added on the end, inject this
	 * object into it as its facet
	 */
	public FacetState createFacetState() {
		HierarchicalPropertyFacetState facetState = new HierarchicalPropertyFacetState();
		facetState.setFacet(this);
		facetState.setId(this.getId() + ".");
//		facetState.setViewName(this.getViewName());
//		facetState.addObject("_facetLabel", label);
		return facetState;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label
	 *            the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * @return the hasChildProperty
	 */
	public Property getHasChildProperty() {
		return hasChildProperty;
	}

	/**
	 * @param hasChildProperty
	 *            the hasChildProperty to set
	 */
	public void setHasChildProperty(Property hasChildProperty) {
		this.hasChildProperty = hasChildProperty;
	}

	/**
	 * @return the hasParentProperty
	 */
	public Property getHasParentProperty() {
		return hasParentProperty;
	}

	/**
	 * @param hasParentProperty
	 *            the hasParentProperty to set
	 */
	public void setHasParentProperty(Property hasParentProperty) {
		this.hasParentProperty = hasParentProperty;
	}

	public Model getOntology() {
		return ontology;
	}
	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public Resource getRootConcept() {
		return rootConcept;
	}

	public void setRootConcept(Resource rootConcept) {
		this.rootConcept = rootConcept;
	}

}
