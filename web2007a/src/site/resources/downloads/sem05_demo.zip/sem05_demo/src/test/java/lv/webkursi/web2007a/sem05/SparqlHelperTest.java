package lv.webkursi.web2007a.sem05;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Suite;
import org.junit.runners.Parameterized.Parameters;

import antlr.Token;

@RunWith(Suite.class)
@Suite.SuiteClasses(value = { SparqlHelperTest.ExtractTests.class,
		SparqlHelperTest.LiteralTests.class, SparqlHelperTest.URLTests.class,
		SparqlHelperTest.VariableTests.class, SparqlHelperTest.QNameTests.class })
public class SparqlHelperTest {

	@RunWith(value = Parameterized.class)
	public static class ExtractTests {
		private String expression;

		private int position;

		private String text;

		public ExtractTests(String expression, int position, String text) {
			this.expression = expression;
			this.position = position;
			this.text = text;
		}

		@Parameters
		public static Collection data() {
			return Arrays.asList(new Object[][] {
					{ "?result :p1 ${label}", 0, "${label}" },
					{ "?result :p1 ${label}", 1, null },
					{ "?result :p1 ${label}; :p2 ${label}", 0, "${label}" },
					{ "?result :p1 ${label}; :p2 ${label}", 1, "${label}" }, 
					{ "?result :p1 ${_a}; :p2 ${_a0}; :p3 ${_a-b} .", 0, "${_a}" }, 
					{ "?result :p1 ${_a}; :p2 ${_a0}; :p3 ${_a-b} .", 1, "${_a0}" }, 
					{ "?result :p1 ${_a}; :p2 ${_a0}; :p3 ${_a-b} .", 2, "${_a-b}" },
					// ignore those variables, which do not have right syntax
					{ "?result :p1 ${_a}; :p2 ${0a}; :p3 ${-b} .", 0,"${_a}" }, 
					{ "?result :p1 ${_a}; :p2 ${0a}; :p3 ${-b} .", 1, null }, 
					{ "?result :p1 ${_a}; :p2 ${a\u0100}; :p3 ${a\n} .", 0,"${_a}" }, 
					{ "?result :p1 ${_a}; :p2 ${a\u0100}; :p3 ${a\n} .", 1, null },
					// ignore variable look-alikes within literal strings
					{ "?result :p1 ${_a}; :p2 \"\\\"${a}\"", 1, null },
					{ "?result :p1 ${_a}; :p2 \"\u0010${a}\"", 1, null },
			});
		}

		@Test
		public void testLiteral() {
			Token t;
			try {
				t = SparqlHelper.extractPlaceholders(expression).get(position);
			} catch (IndexOutOfBoundsException e) {
				assertNull(text);
				return;
			}
			if (t == null) {
				assertNull(text);
			} else {
				assertEquals(text, t.getText());
			}
		}
	}

	@RunWith(value = Parameterized.class)
	public static class LiteralTests {

		private String candidate;

		private boolean isLiteral;

		public LiteralTests(String candidate, boolean isLiteral) {
			this.candidate = candidate;
			this.isLiteral = isLiteral;
		}

		@Test
		public void testLiteral() {
			assertTrue(SparqlHelper.isValidLiteral(candidate) == isLiteral);
		}

		@Parameters
		public static Collection data() {
			return Arrays.asList(new Object[][] {
					{ "a", false }, // no delimiters
					{ "\"a", false }, // no right delimiter
					{ "a\"", false }, // no left delimiter
					{ "'a", false }, // no right delimiter
					{ "a'", false }, // no left delimiter
					{ "\"a\"", true }, // [5], OK
					{ "\"a'", false }, // unmatched delimiters
					{ "'a\"", false }, // unmatched delimiters
					{ "'a'", true }, // [8], OK
					{ "\"a\"a\"", false }, // illegal symbol - unescaped "
					{ "\"a'a\"", true }, // [10], OK
					{ "'a\"a'", true }, // [11], OK
					{ "'a'a'", false }, // illegal symbol - unescaped '
					{ "'a\\a'", false }, // illegal - unescaped '\'
					{ "\"a\\a\"", false }, // illegal - unescaped '\'
					{ "'a\na'", false }, // illegal - unescaped '\n'
					{ "\"a\na\"", false }, // illegal - unescaped '\n'
					{ "'a\ra'", false }, // illegal - unescaped '\r'
					{ "\"a\ra\"", false }, // illegal - unescaped '\r'
					{ "' \\t \\b \\n \\r \\f \\\\ \\\" \\' '", true },
					{ "\" \\t \\b \\n \\r \\f \\\\ \\\" \\' \"", true },
					{ "'\\u0123\\U01234567'", true },
					{ "\"\\u0123\\U01234567\"", true },
					{ "'\\u012\\U01234567'", false },
					{ "\"\\u012\\U01234567\"", false },
					{ "'\\u0123f\\U01234567'", true },
					{ "\"\\u01ef4\\U01234567\"", true },
					{ "\"\\u01ef4\\U01234567\"sometail", false },
					{ "'\\u0123\\U0123456'", false },
					{ "\"\\u0123\\U0123456\"", false },
					{ "'\\u012G\\U0123cdef'", false },
					{ "'\\u012f\\U0123cdeG'", false },
					{ "\"aa\"^^xsd:string", true },
					{ "\"aa^^xsd:string\"", true },
					{ "\"2006-10-31T18:30:00Z^^http://www.w3.org/2001/XMLSchema#dateTime\"^^xsd:dateTime", true }
			});

		}
	}

	@RunWith(value = Parameterized.class)
	public static class URLTests {
		private String candidate;

		private boolean isURL;

		@Test
		public void testURL() {
			assertTrue(SparqlHelper.isValidUrl(candidate) == isURL);
		}

		public URLTests(String candidate, boolean isURL) {
			this.candidate = candidate;
			this.isURL = isURL;
		}

		@Parameters
		public static Collection data() {
			return Arrays.asList(new Object[][] { { "a", false },
					{ "<a", false }, // no right delimiter
					{ "a>", false }, // no left delimiter
					{ "<a>", true }, // [3], OK
					{ "<a<b>", false }, // should not contain '<'
					{ "<a>b>", false }, // should not contain '>'
					{ "<a'b>", false }, // should not contain '
					{ "<a{b>", false }, // should not contain '{'
					{ "<a}b>", false }, // should not contain '}'
					{ "<a|b>", false }, // should not contain '|'
					{ "<a^b>", false }, // should not contain '^'
					{ "<a`b>", false }, // should not contain '`'
					{ "<a\u0000b>", false }, // should not contain \\u0000
					{ "<a\u0007b>", false }, // should not contain \\u0007
					{ "<a\nb>", false }, // should not contain '\n'
					{ "<a\rb>", false }, // should not contain '\r'
					{ "<a b>", false }, // should not contain '\u0020'
					{ "<http://domain.com?p1=v1&p2=v2#fragm1>", true } });
		}
	}

	@RunWith(value = Parameterized.class)
	public static class QNameTests {

		private String candidate;

		private boolean isQName;

		@Test
		public void testQName() {
			assertTrue(SparqlHelper.isValidQName(candidate) == isQName);
		}

		public QNameTests(String candidate, boolean isQName) {
			this.candidate = candidate;
			this.isQName = isQName;
		}

		@Parameters
		public static Collection data() {
			return Arrays.asList(new Object[][] { { "a", false }, // no colon
					{ "\"a\"", false }, // no colon
					{ "<a>", false }, // no colon
					{ "?a", false }, // no colon
					{ "$a", false }, // no colon
					{ ":", true }, // [5], OK
					{ "_a:b", false }, // prefix cannot start with _
					{ "0a:b", false }, // pref should start with a letter
					{ "a_0123:b", true }, // prefix can contain _0-9
					{ "\\u0123_0123:", true }, // [9], OK
					{ "a:_", true }, // [10], OK
					{ "a:0", false }, // cannot start with a digit
					{ "a:b;c", false }, // illegal symbol, ';'
					{ "a:b.-c-", true }, // [13], OK
					{ "a:b..c", true }, // [14], OK
					{ "a:.c", false }, // cannot start with a '.'
					{ "a:c.", false }, // cannot end with a '.'
					{ "a:-c", false } // cannot start with a '-'
					});
		}
	}

	@RunWith(value = Parameterized.class)
	public static class VariableTests {

		private String candidate;

		private boolean isVariable;

		public VariableTests(String candidate, boolean isVariable) {
			this.candidate = candidate;
			this.isVariable = isVariable;
		}

		@Test
		public void testLiteral() {
			assertTrue(SparqlHelper.isValidVariable(candidate) == isVariable);
		}

		@Parameters
		public static Collection data() {
			return Arrays.asList(new Object[][] { { "a", false },
					{ "\"a\"", false }, // same
					{ "<a>", false }, // same
					{ "a:b", false }, // same
					{ "?", false }, // no variable name
					{ "$", false }, // no variable name
					{ "?a", true }, // [6], OK
					{ "$a", true }, // [7], OK
					{ "?0", true }, // [8], OK
					{ "$0", true }, // [9], OK
					{ "?_", true }, // [10], OK
					{ "$_", true }, // [11], OK
					{ "?__\\u01ef__", true }, // [12], OK
					{ "$__\\U0123CDEF__", true }, // [13], OK
					{ "?__\\u01EF__", true }, // [14], OK
					{ "$__\\U0123cdef__", true }, // [15], OK
					{ "?a\"", false }, // illegal symbol "
					{ "?a\n", false }, // illegal symbol '\n'
					{ "?a\r", false }, // illegal symbol '\r'
					{ "?a.", false }, // illegal symbol '.'
					{ "?a;", false }, // illegal symbol ';'
					{ "?a. ?result :p1 ?b", false }, // more illegal symbols
					{ "?a;:p1?b", false } // [22]
					});
		}

	}

}
