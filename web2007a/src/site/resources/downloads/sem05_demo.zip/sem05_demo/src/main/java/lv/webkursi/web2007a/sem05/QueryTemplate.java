package lv.webkursi.web2007a.sem05;

import java.io.StringWriter;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.ResultSetFormatter;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.impl.ResIteratorImpl;

/**
 * TODO untested
 * 
 * Determine a resource list from SPARQL query.
 * 
 * <p>
 * This class runs a SPARQL query and can return an iterator over the list of
 * resources selected by a variable in the query. The default variable is named
 * <code>result</code> but this can be overridden using the the
 * setResultVariableName method.
 * </p>
 * 
 * <p>
 * The component is configured not with a whole SPARQL query, but just with the
 * expression that is used to select the results.
 * </p>
 */
public class QueryTemplate {

	private Log log = LogFactory.getLog(QueryTemplate.class);

	protected String prefixes;

	protected SelectExpression selectExpression;

	protected String resultVariableName = "result";

	protected SparqlDataSource dataSource;
	
	protected long limit = -1;

	protected long offset = 0;

	protected String orderBy = null;

	protected boolean ascending = true;
	
	private QueryExecution qx = null;
	
	
	/**
	 * Construct a new QueryTemplate for bean usage; inject dataSource later
	 */
	public QueryTemplate() {
	}
	
	/**
	 * Construct a new QueryTemplate, given a SparqlDataSource to connect to
	 * @param dataSource
	 */
	public QueryTemplate(SparqlDataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * Set the name of the variable which identifies the list of results to
	 * return.
	 * 
	 * @param resultVariableName
	 *            the name of the result variable.
	 */

	public void setResultVariableName(String resultVariableName) {
		this.resultVariableName = resultVariableName;
	}

	/**
	 * Return an iterator over the resources selected by the query.
	 * 
	 * @return an iterator over the resources selected by the query.
	 * 
	 * <p>
	 * <b>Contract</b>
	 * </p>
	 * <ol>
	 * <li>The iterator returns a resource corresponding to every match of the
	 * resultVariableName in the query result set.</li>
	 * 
	 * <li>Each resource is returned only once.</li>
	 * 
	 * <li>If no results are found then an iterator which returns no resources
	 * is returned.</li>
	 * 
	 * <li>If the variable name resultVariableName does not appear in the
	 * result set a PortalConfigurationException is returned.</li>
	 * 
	 * <li>Each resource can be queried to retrieve its properties.</li>
	 * 
	 * <li>If <code>sortBy</code> is not null, resources are returned ordered
	 * by the value of the <code>orderBy</code> property.</li>
	 * 
	 * <li>The ordering is ascending unless the <code>ascending</code>
	 * attribute is false.</li>
	 * 
	 * <li>If the <code>limit</code> attribute is greater than or equal to
	 * zero, then at most <code>limit</code> results are returned.</li>
	 * 
	 * <li>If <code>sortBy</code> is not null then the results returned start
	 * at the result <code>offset</code> + 1.</li>
	 * 
	 * <li>If <code>offset</code> is greater than 0 and <code>sortBy</code>
	 * is null, than a PortalConfigurationException is thrown.</li>
	 * 
	 * <li>If <code>ascending</code> is false, then the sort order is
	 * descending</li>
	 * </ol>
	 */
	public ResIterator queryForIterator(String expression) {
		this.selectExpression = new SelectExpression(expression);
		Model resultModel = getDescribeModel();
		ResIterator iter = getResultIterator(resultModel);
		return iter;
	}

	public ResIterator queryForIterator(String expression, Map params) {
		this.selectExpression = new SelectExpression(expression, params);
		Model resultModel = getDescribeModel();
		ResIterator iter = getResultIterator(resultModel);
		return iter;
	}

	protected Model getDescribeModel() {
		String queryString = createDescribeQueryString();
		QueryExecution qx = dataSource.query(queryString);
		Model resultGraph = qx.execDescribe();
		qx.close();
		StringWriter sw = new StringWriter();
		resultGraph.write(sw);
		log.debug("Query result graph\n" + sw.toString());
		return resultGraph;
	}

	protected String createDescribeQueryString() {
		String queryString = prefixes;
		queryString += "DESCRIBE ?" + resultVariableName + "\n";
		queryString += "WHERE {" + selectExpression + "}";
		log.info("describe Query = '" + queryString + "'");
		return queryString;
	}

	protected ResIterator getResultIterator(Model resultModel) {
		// TODO kap
		// resultModel is needed - you should query resultModel not the datasource!
		// this avoids many round trips to the database		
		
		String queryString = createSelectQueryString();
		QueryExecution qx = dataSource.query(queryString);
//		QueryExecution qx = resultModel.query(queryString);
		ResultSet resultSet = qx.execSelect();		
		ResIterator iter = createResultsIterator(resultSet, resultVariableName);
		qx.close();
		return iter;
		
		/*
		ResultSet rs = openQueryExecution(createSelectQueryString());		
		ResIterator iter = createResultsIterator(rs, resultVariableName);
		closeQueryExecution();
		return iter;
		*/
	}
	
	/**
	 * TODO kap
	 * This is almost a clone of getResultIterator(Model); probably should refactor
	 * @return
	 */
	public ResultSet openQueryExecution(String expression) {
		selectExpression = new SelectExpression(expression);
		String queryString = createSelectQueryString();
		qx = dataSource.query(queryString);
		ResultSet resultSet = qx.execSelect();
		return resultSet;
	}
	
	public void closeQueryExecution() {
		qx.close();
	}
	

	protected String createSelectQueryString() {
		String queryString = prefixes;
		queryString += "SELECT DISTINCT ?" + resultVariableName + "\n";
		queryString += "WHERE {" + selectExpression + "}\n";
		if (orderBy != null) {
			queryString += "ORDER BY ";
			if (!ascending) {
				queryString += "DESC(?" + orderBy + ")\n";
			} else {
				queryString += "?" + orderBy + "\n";
			}
		}

		if (limit >= 0) {
			queryString += "LIMIT " + limit + "\n";
		}
		if (offset > 0) {
			if (orderBy == null) {
				throw new RuntimeException(
						"Query has offset but no orderBy");
			}
			queryString += "OFFSET " + offset + "\n";
		}
		return queryString;
	}

	protected ResIterator createResultsIterator(ResultSet rs,
			String variableName) {
		Vector<Resource> results = new Vector<Resource>();
		while (rs.hasNext()) {
			QuerySolution s = rs.nextSolution();
			if (s.contains(variableName)) {
				results.add(s.getResource(variableName));
			} else {
				throw new RuntimeException(
						"result variable not used in query");
			}
		}

		// this is maybe a bit naughty - using an internal class from Jena.
		return new ResIteratorImpl(results.iterator());
	}

	/**
	 * @return Returns the dataSource.
	 */
	public SparqlDataSource getDataSource() {
		return dataSource;
	}

	/**
	 * @param dataSource
	 *            The dataSource to set.
	 */
	public void setDataSource(SparqlDataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * @return Returns the limit.
	 */
	public long getLimit() {
		return limit;
	}

	/**
	 * @param limit
	 *            The limit to set.
	 */
	public void setLimit(long limit) {
		this.limit = limit;
	}

	/**
	 * @return Returns the offset.
	 */
	public long getOffset() {
		return offset;
	}

	/**
	 * @param offset
	 *            The offset to set.
	 */
	public void setOffset(long offset) {
		this.offset = offset;
	}

	/**
	 * @return Returns the orderBy.
	 */
	public String getOrderBy() {
		return orderBy;
	}

	/**
	 * @param orderBy
	 *            The orderBy to set.
	 */
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	/**
	 * @return Returns the resultVariableName.
	 */
	public String getResultVariableName() {
		return resultVariableName;
	}

	/**
	 * @return Returns the ascending.
	 */
	public boolean isAscending() {
		return ascending;
	}

	/**
	 * @param ascending
	 *            The ascending to set.
	 */
	public void setAscending(boolean ascending) {
		this.ascending = ascending;
	}

	/**
	 * @return the prefixes
	 */
	public String getPrefixes() {
		return prefixes;
	}

	/**
	 * @param prefixes
	 *            the prefixes to set
	 */
	public void setPrefixes(String prefixes) {
		this.prefixes = prefixes;
	}

	void setLog(Log log) {
		this.log = log;
	}
}