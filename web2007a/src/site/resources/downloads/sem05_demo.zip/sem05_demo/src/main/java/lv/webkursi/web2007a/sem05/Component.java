package lv.webkursi.web2007a.sem05;

/**
 * Portal components objects that are managed by a ComponentManager.
 */
public interface Component {
        
    /**
     * Set the component id
     * 
     * @param id the components name
     */
    public void setId(String id);
    
    /**
     * Get the component id
     * 
     * @return the component's id
     */    
    public String getId();
    
    /**
     * Perform an action
     * 
     * @param action the action to be performed
     */
    public  void doAction(String action);
    
    /**
     * Set interaction state
     * 
     * @param state the interaction state to be set
     */
    public void setInteractionState(String state);
}
