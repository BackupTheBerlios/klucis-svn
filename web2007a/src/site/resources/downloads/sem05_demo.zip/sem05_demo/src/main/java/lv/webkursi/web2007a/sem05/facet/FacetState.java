package lv.webkursi.web2007a.sem05.facet;

import lv.webkursi.web2007a.sem05.AbstractComponent;

/**
 * An object represeting the dynamic state of a facet.
 * 
 * @author bwm
 *
 */
public abstract class FacetState extends AbstractComponent {
	
	public abstract void setFacet(Facet facet);
	
	public abstract Facet getFacet();
	
	protected CompositeFacet parentFacet;
	/**
	 * Get the query fragment for this facet.
	 * 
	 * @return the query fragment
	 */
	public abstract String getQueryFragment(String varName);	
	
	
	public String getPropertyURI() {
		return getFacet().getProperty().getURI();
	}

	public CompositeFacet getParentFacet() {
		return parentFacet;
	}

	public void setParentFacet(CompositeFacet parentFacet) {
		this.parentFacet = parentFacet;
	}
}
