package lv.webkursi.web2007a.sem05.facet;

import java.util.EventObject;

/**
 * @author bwm
 *
 */
@SuppressWarnings("serial")
public class LifecycleEvent extends EventObject {
    
    public enum Kind {execute, prepareToRender};
    
    Kind kind;
    
    /**
     * @param source source of the event
     */
    protected LifecycleEvent(Object source) {
        super(source);
    }
    
    /**
     * 
     * @param source the source of the event
     * @param kind the kind of event
     */
    
    public LifecycleEvent(Object source, Kind kind) {
        this(source);
        this.kind = kind;
    } 

    /**
     * @return Returns the kind.
     */
    public Kind getKind() {
        return kind;
    }
    
    /**
     * @param kind The kind to set.
     */
    public void setKind(Kind kind) {
        this.kind = kind;
    }
}
