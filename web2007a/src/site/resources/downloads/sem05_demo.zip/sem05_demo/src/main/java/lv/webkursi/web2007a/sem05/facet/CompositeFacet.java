package lv.webkursi.web2007a.sem05.facet;

import java.util.List;

import lv.webkursi.web2007a.sem05.AbstractComponent;
import lv.webkursi.web2007a.sem05.QueryTemplate;
import lv.webkursi.web2007a.sem05.ResourceIteratorSource;
import lv.webkursi.web2007a.sem05.SparqlDataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.ResIterator;

/**
 * 
 */
public class CompositeFacet extends AbstractComponent implements
		ResourceIteratorSource {

	private final Log log = LogFactory.getLog(CompositeFacet.class);

	protected String prefixes;

	protected List<FacetState> facets;

	protected SparqlDataSource dataSource;

	protected String label;

	protected long offset = -1;

	protected long limit = -1;

	protected String orderBy = null;

	protected boolean ascending = true;

	protected QueryTemplate template;

	/**
	 * Gather the query fragments from the facets, compose a composite query,
	 * and run it, and return an iterator over the results. Use same trick as
	 * SparqlFindResources - i.e. describe then select
	 */
	public ResIterator getResultsIterator() {
		QueryTemplate template = new QueryTemplate(dataSource);
		StringBuffer selectExpression = new StringBuffer();
		for (int i = 0; i < facets.size(); i++) {
			String fragment = facets.get(i).getQueryFragment("result");
			if (fragment != null && !fragment.equals("")) {
				selectExpression.append(fragment);
				selectExpression.append(". ");
			}
		}

		if (limit >= 0) {
			template.setLimit(limit);
		}

		if (offset >= 0) {
			template.setOffset(offset);
		}

		template.setPrefixes("");
		return template.queryForIterator(selectExpression.toString());
	}

	/**
	 * Compute a set of resources and labels, which should be visible in some
	 * facetState given the current settings of other facets.
	 * 
	 * @param caller
	 *            which facetState is using this to populate its labels
	 * @param selectClause
	 *            it is a SPARQL clause indicating the relation between the
	 *            resources from the dataset "?x" to be filtered with some
	 *            facet-specific variable e.g. "?label", which can be later
	 *            transformed into values populating the facet. For simple
	 *            property facets it is "?x [property-of-the-facet] ?label".
	 * @param modifierClause
	 *            it is the Solution Sequence Modifier for the query: Normally
	 *            the modifiers are "distinct" and "order by ?label"
	 *            (limits/offsets could also be considered) - it is NULL for
	 *            iter-05, the default ordering is by "label".
	 * @return a resultset, from which one can extract String "label"-s
	 */
	public ResultSet prepareQuery(FacetState caller, String selectClause,
			String modifierClause) {

		template = new QueryTemplate();
		template.setDataSource(dataSource);
		template.setOrderBy("label");
		template.setPrefixes("");
		template.setResultVariableName("result");

		StringBuffer selectExpression = new StringBuffer();
		for (FacetState fs : facets) {
			String fragment = null;
			if (!fs.getId().equals(caller.getId())) {
				fragment = fs.getQueryFragment("x");

			} else {
				fragment = selectClause;
			}
			if (fragment != null && !fragment.equals("")) {
				selectExpression.append(fragment);
				selectExpression.append(" . ");
			}
		}
		int len = selectExpression.length();
		selectExpression.delete(len - 3, len);
		ResultSet results = template.openQueryExecution(selectExpression
				.toString());
		return results;
	}

	public void closePrepareQuery() {
		template.closeQueryExecution();
	}

	/**
	 * @param facets
	 *            the facets to set
	 */
	public void setFacets(List<FacetState> facets) {
		this.facets = facets;
	}

	/**
	 * @return the facets
	 */
	public List<FacetState> getFacets() {
		return facets;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label
	 *            the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * @return Returns the dataSource.
	 */
	public SparqlDataSource getDataSource() {
		return dataSource;
	}

	/**
	 * @param dataSource
	 *            The dataSource to set.
	 */
	public void setDataSource(SparqlDataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * Returns limit for SPARQL query
	 */
	public long getLimit() {
		return limit;
	}

	/**
	 * Returns offset for SPARQL query
	 */
	public long getOffset() {
		return offset;
	}

	/**
	 * Sets limit for the SPARQL query TODO bwm This parameter is never
	 * configured or set via action, so this is never called
	 */
	public void setLimit(long limit) {
		this.limit = limit;
	}

	/**
	 * Sets offset for the SPARQL query TODO bwm This parameter is never
	 * configured or set via action, so this is never called
	 */
	public void setOffset(long offset) {
		this.offset = offset;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public boolean isAscending() {
		return ascending;
	}

	public void setAscending(boolean ascending) {
		this.ascending = ascending;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

}
