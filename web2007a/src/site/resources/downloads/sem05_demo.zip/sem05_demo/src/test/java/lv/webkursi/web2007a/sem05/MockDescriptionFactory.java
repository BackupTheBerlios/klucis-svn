package lv.webkursi.web2007a.sem05;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;


import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class MockDescriptionFactory {
	private Map<String, Model> modelCache = new HashMap<String, Model>();
	
//	private static String pathPrefix = "file:src/test/resources/";
	private static String filePrefix = "src/test/resources/";
	
	private static MockDescriptionFactory instance = new MockDescriptionFactory();


	/**
	 * Singleton - constructor called only once per class initialization.
	 * 
	 */
	private MockDescriptionFactory() {
	}

	/**
	 * Get the unique instance
	 * 
	 * @return
	 */
	public static MockDescriptionFactory getInstance() {
		return instance;
	}
	
	
	/**
	 * Should initialize model from a local string, not an external file
	 * @param key
	 * @return
	 */
	@Deprecated
	public Model getPortalDescription(String key) {
		if (modelCache.containsKey(key)) {
			return modelCache.get(key);
		}
        
        Model result = ModelFactory.createDefaultModel();
//        result.read(pathPrefix + key + ".n3", "N3");
        try {
			FileInputStream fis = new FileInputStream(filePrefix + key + ".n3");
			result.read(fis,null,"N3");
		} catch (FileNotFoundException e) {			
			e.printStackTrace();
			throw new RuntimeException(e);
		}
        
		modelCache.put(key, result);
		return result;
	}
	
	
	
	public Model createModel(String key, String description) {
		if (modelCache.containsKey(key)) {
			return modelCache.get(key);
		}
		Model result = ModelFactory.createDefaultModel();
		ByteArrayInputStream bis = new ByteArrayInputStream(description
				.getBytes());
		result.read(bis, null, "N3");

		modelCache.put(key, result);
		return result;
	}

	
	/*
	public static void main(String[] args) {
		String val = System.getProperty("user.dir");
		System.out.println("user.dir is " + val);
	}
	*/
}
