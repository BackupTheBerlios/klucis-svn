package lv.webkursi.web2007a.sem05;

import com.hp.hpl.jena.rdf.model.ResIterator;

/**
 * @author kap
 *
 */
public interface ResourceIteratorSource {
	
    /**
     * An object that can return an iterator of resources.
     * 
     * @return an iterator over a collection of resources.
     */
    public ResIterator getResultsIterator();
    
    /**
     * Set the limit to the number of objects returned
     * 
     * @param limit the limit to set
     */
    public void setLimit(long limit);
    
    /**
     * Get the limit on the number of objects returned
     * 
     * @return the limit
     */
    public long getLimit();
    
    /**
     * Set the offset for the objects returned
     * 
     * @param offset the number of objects to skip
     */
    public void setOffset(long offset);
    
    /**
     * Get the offset for the objects returned
     * 
     * @return the offset
     */
    public long getOffset();
    
	public boolean isAscending();

	public void setAscending(boolean ascending);

	/**
	 * @return Returns the orderBy.
	 */
	public String getOrderBy();

	/**
	 * @param orderBy
	 *            The orderBy to set.
	 */
	public void setOrderBy(String orderBy);

}
