package lv.webkursi.web2007a.sem05;

import com.hp.hpl.jena.query.QueryExecution;

/**
 * @author kap
 *
 */
public interface SparqlDataSource {
    
    /**
     * Run the query on the data source and return a query
     * execution object from which the results can be obtained.
     * 
     * <p>The caller is expected to close the query execution
     * object when done with it to free up resources.</p>
     * 
     * @param query
     * @return the results of the query.
     */
    public QueryExecution query(String query);
}
