package lv.webkursi.web2007a.sem05.facet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;

import lv.webkursi.web2007a.sem05.data.RDFUtil;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Resource;

/**
 * My assumption here is that the template will wish to display the path to
 * current value and then the possible child values next. Each of these will
 * probably be an action link. e.g.
 * 
 * <pre>
 *        level1-value
 *          level2-value
 *            current value
 *              possible-next-refinement1
 *              possible-next-refinement2
 *              possible-next-refinement3
 * </pre>
 * 
 * Making these easily available to the template writer would be a good thing.
 * 
 * 
 * @author bwm
 * 
 */
public class HierarchicalPropertyFacetState extends FacetState {

	protected String currentValuePath = null;

	protected Resource currentValue = null;

	protected HierarchicalPropertyFacet facet;

	private final Log log = LogFactory
			.getLog(HierarchicalPropertyFacetState.class);

	/**
	 * a sequence of labels representing possible refinement values of the
	 * property
	 */
	protected Vector<String> childLabels;

	/**
	 * We get the label for current value - should figure out from that the
	 * actual value of the resource on the assumption that the label is unique.
	 * This will be trickier than for SimplePropertyFacet because the label will
	 * be unique within its peers in the hierarchy but not necessarily unique in
	 * the hierarchy. One way to deal with this would be to have the interaction
	 * state be the labels for the whole path from the root. Their might be a
	 * better way - have a think. try to throw a warning if the label is not
	 * unique. we will have to deal with localization issues here at some point -
	 * but not in this iteration just leave a comment.
	 */
	public void setInteractionState(String state) {
		if (state == null || state.equals("")) {
			currentValuePath = "";
			currentValue = ((HierarchicalPropertyFacet) getFacet()).getRootConcept();
		} else {
			currentValuePath = state;
			currentValue = RDFUtil.getResourceByLabelPath(facet.getOntology(),
					facet.getRootConcept(), facet.getHasChildProperty(), facet
							.getHasParentProperty(), currentValuePath);
		}
		// TODO _localization
		// we will have to deal with localization issues here
	}

	/**
	 * The action is to set the currentValuePath to the value of the action
	 * argument
	 */
	public void doAction(String action) {
		setInteractionState(action);
	}

	/**
	 * @return the facet
	 */
	public Facet getFacet() {
		return facet;
	}

	/**
	 * @param facet
	 *            the facet to set
	 */
	public void setFacet(HierarchicalPropertyFacet facet) {
		this.facet = facet;
	}

	/**
	 * @return the currentValueLabel
	 */
	public String getCurrentValuePath() {
		return currentValuePath;
	}

	/**
	 * Keep the rep-invariant - currentValuePath and currentValue are in sync
	 * @param currentValuePath
	 */
	public void setCurrentValuePath(String currentValuePath) {
		this.currentValuePath = currentValuePath;
		currentValue = RDFUtil.getResourceByLabelPath(facet.getOntology(),
				facet.getRootConcept(), facet.getHasChildProperty(), facet
						.getHasParentProperty(), currentValuePath);
	}

	/**
	 * So here we put some code when the prepare to render event fires. What the
	 * code does is call the composite facet with a prepare query That query
	 * should determine what values this facet could take, given the selections
	 * made by all the other facets. This time the possible values are those
	 * that are the immediate children of the current value. It should then call
	 * the SimplePropertyFacet object to determine the appropriate labels to
	 * display and populate the labels vector.
	 */
	public void lifecycleEvent(LifecycleEvent event) {
		// initialize current value to the root, if no value has been set. 
		if (currentValue == null) {
			setInteractionState("");
		}
		if (event.getKind().equals(LifecycleEvent.Kind.prepareToRender)) {
			CompositeFacet source = getParentFacet();
			ResultSet rs = source.prepareQuery(this, "?x <" + getPropertyURI()
					+ "> ?result", null);
			Model ontology = this.getFacet().getOntology();

			childLabels = new Vector<String>();

			while (rs.hasNext()) {
				QuerySolution sol = rs.nextSolution();
				String sResource = sol.get("result").toString();
				Resource resource = ontology.createResource(sResource);

				boolean child2parent = resource.hasProperty(
						((HierarchicalPropertyFacet) getFacet())
								.getHasParentProperty(), currentValue);
				boolean parent2child = currentValue.hasProperty(
						((HierarchicalPropertyFacet) getFacet())
								.getHasChildProperty(), resource);
				// filter out those, which are direct descendants of the current node
				if (child2parent || parent2child) {
					String label = RDFUtil.getLabel(resource);
					if (label == null) {
						label = "invalid label";
						log.warn("Undefined label in facet " + this.getId()
								+ " for resource " + sResource);
					}
					childLabels.add(label);
				}
			}

//			this.addObject("_childLabels", childLabels);
//			if (currentValuePath != null) {
//				this.addObject("_currentValuePath", currentValuePath);
//				this.addObject("_ancestorLabels", Arrays.asList(StringHelper
//						.splitLabelPath(currentValuePath)));
//			} else {
//				this.addObject("_currentValuePath", "");
//				this.addObject("_ancestorLabels", new ArrayList<String>());
//			}
			source.closePrepareQuery();
		}
//		componentManager.registerInteractionState(this, currentValuePath);

	}

	public String getQueryFragment(String varName) {
		// TODO bwm
		// currently, if no hierarchical facet value has been chosen, 
		// it adds just a dummy SPARQL clause. Should this distinguish
		// between 2 cases - when no facet value has been chosen
		// (i.e. currentValue == null) and when the root value has been chosen
		// (i.e. currentValue == facet.getRootConcept()). 
		// The current code does not distinguish between these 2 cases. 
		if (currentValue == null) {
			return "?" + varName + " ?_dummyProp_" + hashCode()
					+ " ?_dummyVal_" + hashCode();
		} else {
			String valueString = "<" + currentValue.getURI() + ">";
			return "?" + varName + " <" + getPropertyURI() + "> " + valueString;
		}
	}

	public void setFacet(Facet facet) {
		this.facet = (HierarchicalPropertyFacet) facet;
	}

	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setId(String id) {
		// TODO Auto-generated method stub
		
	}
}
