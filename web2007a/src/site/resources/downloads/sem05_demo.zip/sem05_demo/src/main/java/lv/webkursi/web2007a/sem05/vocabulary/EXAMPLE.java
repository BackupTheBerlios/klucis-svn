package lv.webkursi.web2007a.sem05.vocabulary;

import com.hp.hpl.jena.rdf.model.*;

/**
 * @author kap
 
/**
 * Vocabulary definitions for example namespace used in tests 
 */
public class EXAMPLE {
    /** <p>The RDF model that holds the vocabulary terms</p> */
    private static Model m_model = ModelFactory.createDefaultModel();
    /** <p>The namespace of the vocabulary as a string ({@value})</p> */
    public static final String NS = "http://example.com/portal#";
    
    /** <p>The namespace of the vocabulary as a string</p>
     *  @see #NS */
    public static String getURI() {return NS;}
    
    /** <p>The namespace of the vocabulary as a resource</p> */
    public static final Resource NAMESPACE = m_model.createResource( NS );

    /**
     * Resources in the ontology
     */

	public static final Resource Class1 = m_model.createResource( NS + "Class1");
	public static final Resource Class2 = m_model.createResource( NS + "Class2");

    
    /**
     * Properties in the ontology
     */
//    public static final Property ascending = m_model.createProperty( NS + "ascending" );
	
}
