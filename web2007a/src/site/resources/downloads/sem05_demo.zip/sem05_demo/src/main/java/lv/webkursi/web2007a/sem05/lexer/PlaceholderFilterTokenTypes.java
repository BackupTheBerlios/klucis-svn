// $ANTLR 2.7.6 (2005-12-22): "PlaceholderFilter.g" -> "PlaceholderFilter.java"$

package lv.webkursi.web2007a.sem05.lexer;

public interface PlaceholderFilterTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int PLACEHOLDER = 4;
	int HEX = 5;
	int STRING_LITERAL1 = 6;
	int STRING_LITERAL2 = 7;
}
