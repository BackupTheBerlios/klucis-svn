package lv.webkursi.web2007a.sem05;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.hp.hpl.jena.query.util.StringUtils;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.vocabulary.RDFS;

/**
 * Check various fixed queries against RDF data (SparqlFindResources
 * component). 
 * 
 * @author kap
 */
@RunWith(Suite.class)
@Suite.SuiteClasses(value = { SparqlFindResourcesTest.LocalTests.class })
public class SparqlFindResourcesTest {

	public static final String localTests = StringUtils
			.join(
					"\n",
					new String[] {
							"@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .",
							"@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .",
							"@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .",
							"@prefix portal: <http://www.hpl.hp.com/schema/20060830/portal#> .",
							"@prefix : <http://example.com/portal#> .",

							"_:r0 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r0\" .",
							"_:r1 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r1\" .",
							"_:r2 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r2\" .",
							"_:r3 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r3\" .",
							"_:r4 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r4\" .",
							"_:r5 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r5\" .",
							"_:r6 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r6\" .",
							"_:r7 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r7\" .",
							"_:r8 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r8\" .",
							"_:r9 rdfs:comment \"comment\" ;",
							"    rdfs:label \"SparqlFindResources-r9\" .",
							"_:r10 rdf:type :A ; rdf:type :B .",
							"_:r11 rdf:type :A ; rdf:type :B .",
							"_:r12 rdf:type :A ; rdf:type :B ." });

	public static class LocalTests {
		private SparqlFindResources testComponent;

		@Before
		public void setUp() throws FileNotFoundException {
			Model testModel = MockDescriptionFactory.getInstance().createModel(
					"localTests", localTests);
			JenaModelAsSparqlDS ds = new JenaModelAsSparqlDS();
			ds.setModel(testModel);
			testComponent = new SparqlFindResources();
			testComponent.setDataSource(ds);
			testComponent
					.setPrefixes("PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> \n"
							+ "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> \n"
							+ "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> \n"
							+ "PREFIX portal: <http://www.hpl.hp.com/schema/20060830/portal#> \n");
		}

		/**
		 * The iterator returns a resource corresponding to every match of the
		 * resultVariableName in the query result set.
		 */
		@Test
		public void allResources() {
			testComponent.setSelectExpression("?result rdfs:label ?label");
			ResIterator iter = testComponent.getResultsIterator();
			int count = 0;
			while (iter.hasNext()) {
				count++;
				iter.next();
			}
			assertTrue(count == 10);
		}

		/**
		 * Result iterator returns no repetitions
		 */
		@Test
		public void uniqueResource() {
			Set<Resource> results = new HashSet<Resource>();
			testComponent.setSelectExpression("?result rdf:type ?type");
			ResIterator iter = testComponent.getResultsIterator();
			while (iter.hasNext()) {
				Resource r = iter.nextResource();
				assertFalse(results.contains(r));
				results.add(r);
			}
		}

		/**
		 * If no results are found then an iterator which returns no resources
		 * is returned (but not null)
		 */
		@Test
		public void noResources() {
			testComponent.setSelectExpression("?result rdfs:foobar ?label");
			ResIterator iter = testComponent.getResultsIterator();
			int count = 0;
			while (iter.hasNext()) {
				count++;
				iter.next();
			}
			assertTrue(count == 0);
		}

		/**
		 * If the variable name resultVariableName does not appear in the result
		 * set a RuntimeException is returned.
		 */
		@Test(expected = RuntimeException.class)
		public void badVariableName() {
			testComponent.setSelectExpression("?result rdfs:label ?label");
			testComponent.setResultVariableName("foobar");
			testComponent.getResultsIterator();
			assertTrue(false);
		}

		/**
		 * Each resource can be queried to retrieve its properties.
		 */
		@Test
		public void getProperties() {
			testComponent.setSelectExpression("?result rdfs:label ?label");
			ResIterator iter = testComponent.getResultsIterator();
			int count = 0;
			while (iter.hasNext()) {
				Resource r = iter.nextResource();
				String v = r.getRequiredProperty(RDFS.label).getString();
				assertTrue(v.startsWith("SparqlFindResources-r"));
				assertTrue(r.hasProperty(RDFS.comment));
				count++;
			}
			assertTrue(count == 10);
		}

		/**
		 * If <code>sortBy</code> is not null, resources are returned ordered
		 * by the value of the <code>orderBy</code> property.
		 */
		@Test
		public void ordering() {
			testComponent.setSelectExpression("?result rdfs:label ?label");
			testComponent.setOrderBy("label");
			ResIterator iter = testComponent.getResultsIterator();
			int count = 0;
			while (iter.hasNext()) {
				Resource r = iter.nextResource();
				String v = r.getRequiredProperty(RDFS.label).getString();
				assertTrue(v.startsWith("SparqlFindResources-r"));
				assertTrue(v.endsWith(Integer.toString(count)));
				count++;
			}
			assertTrue(count == 10);
		}

		/**
		 * <li>If <code>ascending</code> is false, then the sort order is
		 * descending.
		 */
		@Test
		public void descending() {
			testComponent.setSelectExpression("?result rdfs:label ?label");
			testComponent.setOrderBy("label");
			testComponent.setAscending(false);
			ResIterator iter = testComponent.getResultsIterator();
			int count = 10;
			while (iter.hasNext()) {
				count--;
				Resource r = iter.nextResource();
				String v = r.getRequiredProperty(RDFS.label).getString();
				assertTrue(v.startsWith("SparqlFindResources-r"));
				assertTrue(v.endsWith(Integer.toString(count)));
			}
			assertTrue(count == 0);
		}

		/**
		 * If the <code>limit</code> attribute is greater than or equal to
		 * zero, then at most <code>limit</code> results are returned.
		 */
		@Test
		public void limit() {
			testComponent.setSelectExpression("?result rdfs:label ?label");
			testComponent.setOrderBy("label");
			testComponent.setLimit(5);
			ResIterator iter = testComponent.getResultsIterator();
			int count = 0;
			while (iter.hasNext()) {
				Resource r = iter.nextResource();
				String v = r.getRequiredProperty(RDFS.label).getString();
				assertTrue(v.startsWith("SparqlFindResources-r"));
				assertTrue(v.endsWith(Integer.toString(count)));
				count++;
			}
			assertTrue(count == 5);
		}

		/**
		 * If both <code>sortBy</code> and <code>offset</code> are not null, 
		 * then the results returned start at result <code>offset + 1</code>.
		 */
		@Test
		public void offset() {
			testComponent.setSelectExpression("?result rdfs:label ?label");
			testComponent.setOrderBy("label");
			testComponent.setOffset(5);
			ResIterator iter = testComponent.getResultsIterator();
			int count = 5;
			while (iter.hasNext()) {
				Resource r = iter.nextResource();
				String v = r.getRequiredProperty(RDFS.label).getString();
				assertTrue(v.startsWith("SparqlFindResources-r"));
				assertTrue(v.endsWith(Integer.toString(count)));
				count++;
			}
			assertTrue(count == 10);
		}

		/**
		 * If <code>offset</code> is greater than 0 and <code>sortBy</code>
		 * is null, than a RuntimeException is thrown.
		 */
		@Test(expected = RuntimeException.class)
		public void noSortBy() {
			testComponent.setSelectExpression("?result rdfs:label ?label");
			testComponent.setOffset(5);
			testComponent.getResultsIterator();
			assertTrue(false);
		}
	}

}
