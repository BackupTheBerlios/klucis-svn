package lv.webkursi.web2007a.sem05;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.startsWith;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.junit.Before;
import org.junit.Test;


public class SelectExpressionTest {
	
	private Map<String,String[]> parameters = new HashMap<String,String[]>();
	
	@Before
	public void setUp() {
		parameters.clear();
	}

	/**
	 * If there are no parameters to substitute in selectExpression, and
	 * substituteParameters() is invoked, then<br />
	 * substitutedSelectExpression is equal to selectExpression (and as in
	 * all other cases, selectExpression does not change)
	 */
	@Test
	public void substituteNoParameters() {
		parameters.put("p1", new String[] {"value1"});
		parameters.put("p2", new String[] { "v21", "v22" });
		String expression = "?result rdfs:label ?label";
		SelectExpression se = new SelectExpression(expression,parameters);
		assertEquals(expression, se.toString());
	}

	/**
	 * If some placeholder does not have a request parameter to set, and
	 * substituteParameters() is invoked, then<br />
	 * RuntimeException is thrown
	 */
	@Test
	public void substituteNonexistentParameter() {
		String expression = "?result rdfs:label ${label}";
		SelectExpression se = new SelectExpression(expression);
		try {
			se.toString();
			fail("Should fail in substituteParameters");
		} catch (RuntimeException e) {
			// ignore
		}
	}

	/**
	 * If some placeholder does not have a request parameter to set, and
	 * substituteParameters() is invoked, then<br />
	 * RuntimeException is thrown
	 */
	@Test
	public void substituteInvalidParameter() {
		parameters.put("label", new String[] {"\"abc\"\""});
		String expression = "?result rdfs:label ${label}";
		SelectExpression se = new SelectExpression(expression,parameters);
		try {
			se.toString();
			fail("Should fail in substituteParameters");
		} catch (RuntimeException e) {
			// ignore
		}
	}

	/**
	 * If some placeholder has several values in the request and
	 * substituteParameters() is invoked, then<br />
	 * the first value is actually used and a warning is logged
	 */
	@Test
	public void substituteMultiValuedParameter() {
		parameters.put("label", new String[] {"\"val1\"",
				"\"val1\""});
		String expression = "?result rdfs:label ${label}";
		SelectExpression se = new SelectExpression(expression,parameters);
		Log mockLog = createMock(Log.class);
		se.setLog(mockLog);
		mockLog.warn(startsWith("Multiple values for parameter"));
		replay(mockLog);		
		String substitutedExpression = se.toString();
		assertEquals("?result rdfs:label \"val1\"", substitutedExpression);
	}

	/**
	 * If there are several placeholders in the request which are mapped to
	 * a literal, a QName, a variable and a URL respectively, then,<br />
	 * these are replaced in the substitutedSelectExpression
	 */
	@Test
	public void substituteMultipleParameters() {
		parameters.put("p1", new String[] {"\"literal\""});
		parameters.put("p2", new String[] {"prefix:qname"});
		parameters.put("p3", new String[] {"?variable"});
		parameters.put("p4", new String[] {"<http://www.google.com>"});
		// this should NOT be replaced, as ${p5} is within a literal
		parameters.put("p5", new String[] {"blah"});
		String expression = "?result :p1 ${p1}; :p2 ${p2}; :p3 ${p3}; :p4 ${p4}; :p5 \"${p5}\".";
		
		SelectExpression se = new SelectExpression(expression,parameters);
		assertEquals("?result :p1 \"literal\"; :p2 prefix:qname; :p3 ?variable; :p4 <http://www.google.com>; :p5 \"${p5}\".", se.toString());
		
	}
}
