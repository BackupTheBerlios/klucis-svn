package lv.webkursi.web2007a.sem05;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import antlr.Token;

/**
 * A class encapsulating SPARQL query expression
 * and placeholder replacement functionality
 * 
 * @author kap
 */
public class SelectExpression {

	private Log log = LogFactory.getLog(SelectExpression.class);

	private String expression;

	/*
	 * TODO
	 * Add generics <String,Object> or similar
	 */
	private Map parameters;

	String substitutedExpression;

	public SelectExpression() {
	}

	public SelectExpression(String expression) {
		this.expression = expression;
		substitutedExpression = null;
	}

	public SelectExpression(String expression, Map parameters) {
		this.expression = expression;
		this.parameters = parameters;
		substitutedExpression = null;
	}

	public void setExpression(String expression) {
		this.expression = expression;
		substitutedExpression = null;
	}

	public void setParameters(Map parameters) {
		this.parameters = parameters;
		substitutedExpression = null;
	}

	
	public String getExpression() {
		return expression;
	}

	public Map getParameters() {
		return parameters;
	}

	/**
	 * We need to substitute any parameters in the select expression.
	 * getSelectExpression would still return the configured value, but
	 * substitutedSelectExpression variable is set with the replacements.
	 * 
	 * Subsitition for a term should not add new patterns to the query - the
	 * syntax tree should remain the previous, and only the leaf-nodes of 4
	 * different types (literals, SPARQL variables starting with '?', URLs and
	 * QNames). We don't do any escaping here - let the caller get
	 * the parameter value right (including extra surrounding quotes for string literals)
	 * 
	 * PortalException is thrown, if some placeholder does not have the
	 * corresponding HTTP request parameter.
	 */
	protected void substituteParameters() {
		StringBuffer result = new StringBuffer(expression);
		List<Token> placeholders = SparqlHelper.extractPlaceholders(expression);
		if (placeholders.size() == 0) {
			substitutedExpression = result.toString();
			return;
		}

		Map<String, String> params = new HashMap<String, String>();
		for (Token token : placeholders) {
			String varName = token.getText().substring(2,
					token.getText().length() - 1);
			String[] vals = (String[]) parameters.get(varName);
			if (vals == null || vals.length == 0) {
				throw new RuntimeException("Required query parameter '"
						+ varName + "' missing from request parameters");
			}
			if (vals.length > 1) {
				log.warn("Multiple values for parameter '" + varName
						+ "', taking value '" + vals[0]
						+ "' and discarding others");
			}
			if (!SparqlHelper.isValid(vals[0])) {
				throw new RuntimeException(
						"Invalid value '"
								+ vals[0]
								+ "' for query parameter '"
								+ varName
								+ "'; should be SPARQL literal, QName, URL or query variable");

			}
			params.put(token.getText(), vals[0]);
		}

		for (int j = placeholders.size() - 1; j >= 0; j--) {
			Token token = placeholders.get(j);
			int start = token.getColumn() - 1;
			int end = start + token.getText().length();
			result.replace(start, end, params.get(token.getText()));
		}
		substitutedExpression = result.toString();
	}

	public String toString() {
		if (substitutedExpression == null) {
			if (expression != null) {
				if (parameters == null) {
					parameters = new HashMap<String, Object>();
				}
				substituteParameters();
			} else {
				log
						.error("Call setExpression(selectExpression) and, if needed "
								+ "setParameters(parameters) - a map of replacements");
			}
		}
		return substitutedExpression;
	}

	public void setLog(Log log) {
		this.log = log;
	}

	
}
