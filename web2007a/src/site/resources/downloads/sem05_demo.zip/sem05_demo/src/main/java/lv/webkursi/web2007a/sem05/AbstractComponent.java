package lv.webkursi.web2007a.sem05;

/**
 * 
 */
public abstract class AbstractComponent implements Component {
        protected String id;


    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    } 
    
    /**
     * Default doAction method which throws an UnsupportedOperationException.
     * 
     * @param action the action to be performed.
     */
    public void doAction(String action) {
        throw new UnsupportedOperationException(this.getClass().getName() + 
               " component '" + id +"' does not support action '" + action + "'");
    }
    
    /**
     * Default setInteractionState method which throws an UnsupportedOperationException.
     * 
     * @param state the state to be set.
     */
    public void setInteractionState(String state) {
        throw new UnsupportedOperationException(this.getClass().getName() + 
                " component '" + id + "' does not support method setInteractionState()");
    }
}
