package lv.webkursi.web2007a.sem05.facet;

import lv.webkursi.web2007a.sem05.Component;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Property;

/**
 * A facet which can participate in a facetted browse.
 */
public interface Facet extends Component {
	/**
	 * Create a new state object for this facet.
	 * 
	 * @return the newly created state object.
	 */
	public FacetState createFacetState();
		
	public Model getOntology();
	
	public Property getProperty();
	
}
