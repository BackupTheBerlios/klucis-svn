package lv.webkursi.web2007a.sem05.facet;

import lv.webkursi.web2007a.sem05.data.RDFUtil;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import lv.webkursi.web2007a.sem05.AbstractComponent;


/**
 * A Facet which filters results based on a property value.
 */
public class SimplePropertyFacet extends AbstractComponent implements Facet {

	protected Property property; // the property the facet filters on

	protected Model ontology;

	protected String label;

	protected String viewName;

	/**
	 * Lookup the ontology to find the label associated with r the label is the
	 * rdfs:label of the property but be careful of language variants - this
	 * will need to be local aware at some point. I'm not sure if its worth
	 * caching the labels; lets not for now - its an optimization that can be
	 * done later.
	 * 
	 * TODO _optimization
	 * consider caching approach - the same resource may need its label
	 * computed many times
	 * 
	 * @param r
	 */
	public void getLabel(Resource r) {
		label = RDFUtil.getLabel(r);
	}

	/**
	 * @return the property
	 */
	public Property getProperty() {
		return property;
	}

	/**
	 * @param property
	 *            the property to set
	 */
	public void setProperty(Property property) {
		this.property = property;
	}

	/**
	 * @param ontology
	 *            the ontology to set
	 */
	public void setOntology(Model ontology) {
		this.ontology = ontology;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label
	 *            the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public Model getOntology() {
		return ontology;
	}

	/**
	 * create a new SimplePropertyFacetState; give it the same ID as this
	 * component but with a "." added on the end; inject this object into it as
	 * its facet
	 */
	public FacetState createFacetState() {
		SimplePropertyFacetState facetState = new SimplePropertyFacetState();
		facetState.setFacet(this);
		facetState.setId(this.getId() + ".");
//		facetState.setViewName(this.getViewName());
//		facetState.addObject("_facetLabel", label);
		return facetState;
	}

}
