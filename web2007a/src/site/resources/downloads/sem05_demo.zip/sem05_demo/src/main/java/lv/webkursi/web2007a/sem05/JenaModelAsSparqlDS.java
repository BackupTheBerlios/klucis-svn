package lv.webkursi.web2007a.sem05;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.rdf.model.Model;

/**
 * TODO untested
 */
public class JenaModelAsSparqlDS implements SparqlDataSource {
	
	private final Log log = LogFactory.getLog(JenaModelAsSparqlDS.class);
    
    protected Model model;

    public QueryExecution query(String queryString) {
    	log.debug(queryString);
    	QueryExecution result = QueryExecutionFactory.create(queryString, model);
    	log.debug("Finished processing query");
    	return result;
    }

    /**
     * @return Returns the model.
     */
    public Model getModel() {
        return model;
    }

    /**
     * @param model The model to set.
     */
    public void setModel(Model model) {
        this.model = model;
    }   

}
