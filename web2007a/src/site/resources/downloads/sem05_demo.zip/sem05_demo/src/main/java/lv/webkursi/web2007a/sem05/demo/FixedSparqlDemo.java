package lv.webkursi.web2007a.sem05.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.ResultSetFormatter;
import com.hp.hpl.jena.query.util.StringUtils;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

/**
 * This example is adopted from
 * http://www-128.ibm.com/developerworks/xml/library/j-sparql/ Philip McCarthy
 * "Search RDF data with SPARQL"
 * 
 * @author kap
 */
public class FixedSparqlDemo {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		InputStream in = new FileInputStream(new File(
				"src/main/resources/test.n3"));
		Model model = ModelFactory.createMemModelMaker().createDefaultModel();
		model.read(in, null, "N3");
		in.close();

		String queryString = StringUtils.join("\n", new String[] {
				"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>",
				"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>",
				"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>",
				"PREFIX we: <http://www.hpl.hp.com/schema/20061103/whatever#>",
				"PREFIX : <http://example.com/portal#>",
				"SELECT ?title ?credits ?professor", "WHERE {",
				"?x :title \"Various Sciences\";", "  :courses ?y.",
				"# rdfs:member is a super-property of rdf:_1, rdf:_2, etc.",
				"?y rdfs:member ?z.", "?z we:title ?title;",
				"  we:credits ?credits;", "  we:professor ?professor", "}" });

		System.out.println(queryString);
		Query query = QueryFactory.create(queryString);
		QueryExecution qe = QueryExecutionFactory.create(query, model);
		ResultSet results = qe.execSelect();

		ResultSetFormatter.out(System.out, results, query);
		qe.close();
	}

}
