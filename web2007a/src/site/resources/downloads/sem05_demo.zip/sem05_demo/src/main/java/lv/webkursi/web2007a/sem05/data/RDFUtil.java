package lv.webkursi.web2007a.sem05.data;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.util.iterator.ExtendedIterator;
import com.hp.hpl.jena.util.iterator.Filter;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;

public class RDFUtil {

	public static ResourceComparator comparatorInstance;

	private static Log log = LogFactory.getLog(RDFUtil.class);

	public static ResourceComparator getComparator() {
		if (comparatorInstance == null) {
			comparatorInstance = new ResourceComparator();
		}
		return comparatorInstance;
	}

	/**
	 * Get an alphabetically sorted list of types for a resource (e.g. for error
	 * messages)
	 */
	public static Set<Resource> getSortedTypes(Resource resource) {
		Set<Resource> set = new TreeSet<Resource>(getComparator());
		for (ExtendedIterator i = getAllTypes(resource); i.hasNext();) {
			set.add((Resource) i.next());
		}
		return set;
	}

	/**
	 * Return the iterator of all explicitly declared rdf:type-s for the given
	 * resource. The resulting iterator does NOT guarantee any certain ordering
	 * of the returned types.
	 * 
	 * @param r
	 *            the resource
	 * @return list of all types or empty list, if no types are found
	 */
	public static ExtendedIterator getAllTypes(Resource resource) {
		Model model = resource.getModel();
		NodeIterator i = model.listObjectsOfProperty(resource, RDF.type);
		return i.filterKeep(new Filter() {
			@Override
			public boolean accept(Object o) {
				return (o instanceof Resource);
			}
		});
	}

	public static int getIntProperty(Resource r, Property p, int intDefault) {
		int result = intDefault;
		if (r.getProperty(p) != null) {
			try {
				result = r.getRequiredProperty(p).getInt();
			} catch (RuntimeException e) {
				log.warn("Cannot coerce resource '" + r + "' property '" + p
						+ "' to int; using default" + intDefault, e);
			}
		}
		return result;
	}

	/**
	 * @param r
	 *            the resource to inspect
	 * @param p
	 *            the property
	 * @param stringDefault
	 *            the default value, if no value is found
	 * @param isSingle
	 *            should this fail, if property value is non-unique
	 * @return the property value coerced to a String
	 */
	public static String getStringProperty(Resource r, Property p,
			String stringDefault, boolean isSingle) {
		String result = stringDefault;
		Model model = r.getModel();
		NodeIterator i = model.listObjectsOfProperty(r, p);
		int count = 0;
		while (i.hasNext()) {
			try {
				result = ((Literal) i.nextNode()).getString();
			} catch (Exception e) {
				log.warn("Could not coerce resources " + r + " property " + p
						+ " to a string. Using default.", e);
			}
			count++;
		}
		if (isSingle && count > 1) {
			log
					.error("Nonunique value of property " + p
							+ " for resource " + r);
			throw new RuntimeException("Nonunique value of property " + p
					+ " for resource " + r);
		}
		return result;
	}

	/**
	 * This is used to pick the alphabetically first resource, whenever we need
	 * to pick between alternatives (e.g. in ResourceToComponentByType).
	 * 
	 * @author kap
	 */
	public static class ResourceComparator implements Comparator<Resource> {
		public int compare(Resource r1, Resource r2) {
			return r1.getURI().compareTo(r2.getURI());
		}
	}

	/**
	 * <p>
	 * <b>Contract</b>
	 * </p>
	 * 
	 * <ol>
	 * <li>If there are no rdfs:label properties as literals without any
	 * language (i.e. without the xml:lang attribute in RDF/XML notation), then
	 * return null</li>
	 * <li>If there are several rdfs:label properties without language, return
	 * any one and log a warning</li>
	 * <li>Any rdfs:label properties, which are not literals are ignored, and
	 * any non-string values are coerced to strings</li>
	 * </ol>
	 */

	public static String getLabel(Resource resource) {
		return getLabel(resource, null);
	}

	/**
	 * <p>
	 * <b>Contract</b>
	 * </p>
	 * 
	 * <ol>
	 * <li>If there are no rdfs:label properties as literals with the given
	 * locale's language or without language, then return null</li>
	 * <li>If there are any rdfs:label properties with the needed language,
	 * then return one of them (they have highest priority)</li>
	 * <li>If there are only rdfs:label properties without a language, then
	 * return one of them (they have a lower priority)</li>
	 * <li>If there is any ambiguity (several labels with same highest
	 * priority), return any one and log a warning</li>
	 * <li>Any rdfs:label values, which are not literals are ignored, and any
	 * non-string values are coerced to strings</li>
	 * </ol>
	 * 
	 * @param resource
	 * @return
	 */
	public static String getLabel(Resource resource, Locale locale) {
		String language = locale == null ? null : locale.getLanguage();
		String[] result = new String[2];
		StmtIterator iterator = resource.listProperties(RDFS.label);
		int ambiguityFlags = 0x00000000;
		while (iterator.hasNext()) {
			Statement stmt = iterator.nextStatement();
			RDFNode node = stmt.getObject();
			if (node.isLiteral()) {
				ambiguityFlags |= langSpecificStringLiteral((Literal) node,
						result, language);
			} else {
				// ignore those labels, which are not literals
				continue;
			}
		}
		// set priority = 0, if the highest priority match is available
		// otherwise set priority = 1
		int priority = (result[0] == null) ? 1 : 0;
		if ((ambiguityFlags & (1 << priority)) != 0) {
			log.warn("Ambiguous rdfs:label for resource " + resource
					+ ", locale " + locale);
		}
		return result[priority];
	}

	/**
	 * Update the array of strings 'result' (indexed by priority) with literals,
	 * whose language matches the 'language' argument and set the ambiguitiy
	 * flag, if appropriate
	 * 
	 * @param literal
	 *            the literal value to check
	 * @param language
	 *            code for a language or null, if literals without language are
	 *            desired
	 * @return ambiguity flag (0 - no ambiguity, 1 - ambiguity for the highest
	 *         priority values, 2 - ambiguity for the lowest priority, 3 -
	 *         ambiguity for both)
	 */
	private static int langSpecificStringLiteral(Literal literal,
			String[] result, String language) {
		int flag = 0x00000000;
		language = (language == null) ? "" : language;
		String lang = literal.getLanguage();
		int priority = -1;
		if (language.equals(lang)) {
			priority = 0;
		} else if (lang.equals("")) {
			priority = 1;
		}
		if (priority >= 0 && result[priority] == null) {
			result[priority] = literal.getString();
		} else if (priority >= 0) {
			flag = 1 << priority;
		}
		return flag;
	}

	public static void setLog(Log log) {
		RDFUtil.log = log;
	}

	/**
	 * <p>
	 * <b>Contract</b>
	 * </p>
	 * 
	 * <ul>
	 * <li> if r has no portal:id property, but does have a URI with a fragment
	 * identifier then id is the fragment identifier. </li>
	 * <li> if r has no portal:id property and a URI without a fragment
	 * identifier then id is the URI. </li>
	 * <li> if r has no portal:id property and no URI then the bnode id of the r
	 * is the id prefixed with a constant to ensure uniqueness. </li>
	 * </ul>
	 * 
	 * @param r
	 *            resource, which needs implicit Id computed
	 * @return localName, URL, or BNode identifier prefixed with a constant
	 *         string "__" (2 underbars)
	 */
	public static String getImplicitId(Resource r) {
		// return localName
		String id = r.getLocalName();
		if (id != null) {
			return id;
		}
		// return full URL
		id = r.getURI();
		if (id != null) {
			return id;
		}
		// return blank node's id
		id = r.getId().toString();
		return "__" + id;
	}

	/**
	 * p> <b>Contract</b>
	 * </p>
	 * 
	 * <ul>
	 * <li>Return a resource in the ontology with the given label, provided the
	 * label in the ontology has either the specified language (xml:lang
	 * attribute) or no language at all</li>
	 * <li>Return null, if no such resource is found.</li>
	 * <li>If locale is null, then ignore all those labels in the ontology with
	 * explicit xml:lang</li>
	 * <li>If locale is not null, then first search among labels with the given
	 * language, and return it (highest priority). If none such exists, then
	 * search among labels without any language (next priority).</li>
	 * <li>Log a warning, if there are several eligible resources of the same
	 * priority.</li>
	 * </ul>
	 * 
	 * @param ontology
	 * @param label
	 * @param locale
	 * @return
	 */
	public static Resource getResourceByLabel(Model ontology, String label,
			Locale locale) {
		String language = locale == null ? null : locale.getLanguage();
		Literal literal = null;
		if (language != null) {
			literal = ontology.createLiteral(label, language);
		} else {
			literal = ontology.createLiteral(label);
		}
		ResIterator iterator = ontology.listSubjectsWithProperty(RDFS.label,
				literal);
		int count = 0;
		Resource r = null;
		while (iterator.hasNext()) {
			Resource candidate = iterator.nextResource();
			count++;
			if (count != 1) {
				log.warn("Label '" + label + "' has matching resource #"
						+ count + " :" + candidate);
			}
			r = candidate;
		}
		if (locale != null && r == null) {
			// try lower priority literals - those without language
			return getResourceByLabel(ontology, label, null);
		} else {
			return r;
		}
	}

	public static Resource getResourceByLabel(Model ontology, String label) {
		return getResourceByLabel(ontology, label, null);
	}

	/**
	 * Return a resource "b" such that "b rdfs:label label" AND ("a downProperty
	 * b" OR "b upProperty a"). If there are several such resources "b", then
	 * return any one of them and log a warning.
	 * 
	 * (Could be also implemented via rules or via SPARQL query)
	 * 
	 * @param a
	 *            the parent resource
	 * @param label
	 *            the label of the child
	 * @param downProperty
	 *            property going from parent to a child
	 * @param upProperty
	 *            inverse - going from child to the parent
	 * @return the child in the hierarchy.
	 */
	public static Resource jumpToLabel(Resource a, String label,
			Property downProperty, Property upProperty) {
		List<Resource> results = new ArrayList<Resource>();

		StmtIterator iter = a.getModel()
				.listStatements(null, RDFS.label, label);
		while (iter.hasNext()) {
			Resource r = iter.nextStatement().getSubject();
			if (r.hasProperty(upProperty, a) || a.hasProperty(downProperty, r)) {
				results.add(r);
			}
		}
		if (results.size() == 0) {
			throw new RuntimeException("Cannot find a child of '" + a
					+ "' with label '" + label + "'");
		}
		if (results.size() > 1) {
			log.warn("Multiple resources under '" + a + "' with label '"
					+ label + "'");
		}
		return results.get(0);
	}

	/**
	 * Navigate from resource "root" to the "result" by using directed edges "A
	 * downProperty B" (where "B rdfs:label path[i]") for i=0,1,2... If such "A
	 * downProperty B" does not exist in the model, attempt to use the inverse
	 * 
	 * @param model
	 *            the model, which is traversed by the path
	 * @param root
	 *            the original resource, where the following the path starts
	 * @param downProperty
	 *            the property, which navigates down from root to result
	 * @param upProperty
	 *            assumed to be the inverse of downProperty
	 * @param path
	 * @param locale
	 * @return
	 */
	public static Resource getResourceByLabelPath(Model model, Resource root,
			Property downProperty, Property upProperty, String path,
			Locale locale) {
		String[] elts = splitLabelPath(path);
		Resource result = model.createResource(root.getURI());
		for (int i = 0; i < elts.length; i++) {
			result = jumpToLabel(result, elts[i], downProperty, upProperty);
		}
		return result;
	}

	public static Resource getResourceByLabelPath(Model ontology,
			Resource root, Property downProperty, Property upProperty,
			String currentValuePath) {
		return getResourceByLabelPath(ontology, root, downProperty, upProperty,
				currentValuePath, null);
	}

	public static String[] splitLabelPath(String labelPath) {
		if (labelPath.equals("")) {
			return new String[0];
		}
		String labelPath1 = labelPath.substring(1);
		return labelPath1.split("/");
	}

}