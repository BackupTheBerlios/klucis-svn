package lv.webkursi.web2007a.sem05.facet;

import java.util.Vector;

import lv.webkursi.web2007a.sem05.data.RDFUtil;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.Resource;

/**
 * @author bwm
 * 
 */
public class SimplePropertyFacetState extends FacetState {

	/**
	 * the label of the current selected value
	 */

	private final Log log = LogFactory.getLog(SimplePropertyFacetState.class);

	protected String currentValueLabel = null;

	protected Resource currentValue = null;

	protected SimplePropertyFacet facet;
	
	/**
	 * a sequence of labels representing possible values of the property
	 */
	protected Vector<String> labels;

	public void setInteractionState(String state) {
		if (state == null || state.equals("")) {
			currentValueLabel = null;
			currentValue = null;
		} else {
			currentValueLabel = state;
			currentValue = RDFUtil.getResourceByLabel(
					((SimplePropertyFacet) getFacet()).getOntology(),
					currentValueLabel);

		}
		// TODO _localization
		// we will have to deal with localization issues here
	}

	/**
	 * Behavior of doAction() does not depend on the previous state of the
	 * facetState, it overwrites it completely; so it can simply call
	 * setInteractionState().
	 */
	public void doAction(String action) {
		setInteractionState(action);
	}

	/**
	 * @return the facet
	 */
	public Facet getFacet() {
		return facet;
	}

	/**
	 * @param facet
	 *            the facet to set
	 */
	public void setFacet(SimplePropertyFacet facet) {
		this.facet = facet;
	}

	/**
	 * @return the currentValueLabel
	 */
	public String getCurrentValueLabel() {
		return currentValueLabel;
	}

	public Resource getCurrentValue() {
		return currentValue;
	}

	/**
	 * Code for the prepare-to-render event. The code calls the composite facet
	 * with a prepare query. That query should determine what values this facet
	 * could take, given the selections made by all the other facets. It should
	 * then call the SimplePropertyFacet object to determine the appropriate
	 * labels to display and populate the labels vector.
	 */
	public void lifecycleEvent(LifecycleEvent event) {
		if (event.getKind().equals(LifecycleEvent.Kind.prepareToRender)) {
//			CompositeFacet source = (CompositeFacet) event.getSource();
			CompositeFacet source = getParentFacet();
			ResultSet rs = source.prepareQuery(this, "?x <" + getPropertyURI()
					+ "> ?result", null);
			Model ontology = this.getFacet().getOntology();
			labels = new Vector<String>();
			while (rs.hasNext()) {
				QuerySolution sol = rs.nextSolution();
				String sResource = sol.get("result").toString();
				Resource resource = ontology.createResource(sResource);
				String label = RDFUtil.getLabel(resource);
				if (label == null) {
					label = "invalid label";
					log.warn("Undefined label in facet " + this.getId()
							+ " for resource " + sResource);
				}
				labels.add(label);
			}
//			this.addObject("_labels", labels);
//			if (currentValueLabel != null) {
//				this.addObject("_currentValueLabel", currentValueLabel);
//			}
			source.closePrepareQuery();
		}
//		componentManager.registerInteractionState(this, currentValueLabel);
	}

	/**
	 * Given the variable name, return a SPARQL clause, which shows the
	 * restriction imposed by this facetState. E.g. if varName="result", and the
	 * property of the facet is ns:prop, and the actual value of the facetState
	 * is 17, then the clause is "?result ns:prop 17". If there is no actual
	 * value then return a dummy clause like "?result ?id123 ?id456" (this is
	 * needed, if someone wants to list all the resources in dataSource
	 * regardless of whether they have property ns:prop at all.
	 */
	public String getQueryFragment(String varName) {
		if (currentValue == null) {

			// XTODO kap - I think this is wrong
			// if you do this the query will only return resources that have a
			// value for this property
			// we want resources even if they have no value for this property
			// so I think we drop this 'if' clause - check with bwm if you
			// disagree
			// if this facet has a null current value then it does no filtering
			// and the query string returned is the empty string

			// TODO bwm
			// OK, i changed it - you are probably right.
			// Should we add additional configuration of CompositeFacet?
			// I.e. the static part of the selectExpression. Otherwise, if no
			// facet has any value then the SPARQL query will return every
			// resource that is in the data set, since there won't be any WHERE
			// clauses.

			// valueString = "?_var_" + getId();
			return "?" + varName + " ?_dummyProp_" + hashCode()
					+ " ?_dummyVal_" + hashCode();
		} else {
			String valueString = "<" + currentValue.getURI() + ">";
			return "?" + varName + " <" + getPropertyURI() + "> " + valueString;
		}
	}

	public void setFacet(Facet facet) {
		this.facet = (SimplePropertyFacet) facet;
	}

	public Vector<String> getLabels() {
		return labels;
	}

	public void setLabels(Vector<String> labels) {
		this.labels = labels;
	}

	public String toString() {
		StringBuffer result = new StringBuffer();
		result.append("SimplePropertyFacetState(id=");
		result.append(getId());
		result.append(",labels=");
		result.append(labels.toString());
		result.append(")");
		return result.toString();
	}
}
