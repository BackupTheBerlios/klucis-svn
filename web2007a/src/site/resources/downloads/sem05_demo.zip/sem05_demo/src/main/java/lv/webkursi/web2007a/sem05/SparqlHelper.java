package lv.webkursi.web2007a.sem05;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import lv.webkursi.web2007a.sem05.lexer.PlaceholderFilter;
import lv.webkursi.web2007a.sem05.lexer.PlaceholderFilterTokenTypes;

import antlr.Token;
import antlr.TokenStreamException;

@Deprecated
public class SparqlHelper {

	public static Log log = LogFactory.getLog(SparqlHelper.class);

	/**
	 * Extract all placeholders and return them as a list of tokens
	 * 
	 * @param expression
	 * @return
	 */
	public static List<Token> extractPlaceholders(String expression) {
		List<Token> result = new ArrayList<Token>();
		StringReader reader = new StringReader(expression);
		PlaceholderFilter lexer = new PlaceholderFilter(reader);
		for (;;) {
			Token token;
			try {
				token = lexer.nextToken();
			} catch (TokenStreamException e) {
				log.error(e);
				return new ArrayList<Token>();
			}
			if (token == null
					|| token.getType() == PlaceholderFilterTokenTypes.EOF) {
				break;
			}
			if (token.getType() == PlaceholderFilterTokenTypes.PLACEHOLDER) {
				result.add(token);
			}
		}
		return result;
	}

	/**
	 * Return true iff the argument is a literal string (in quotes or
	 * apostrophies), correctly escaped accordingly to SPARQL syntax. See
	 * STRING_LITERAL1, STRING_LITERAL2 here
	 * http://www.w3.org/TR/rdf-sparql-query/#rSTRING_LITERAL1 . Or, if it is a
	 * string literal with some datatype specified (separated with ^^).
	 */
	public static boolean isValidLiteral(String value) {
		String STRING_LITERAL1_REGEX = "'([^'\\\\\\n\\r]|\\\\[tbnrf\"']|\\\\\\\\|\\\\u[0-9a-fA-F]{4}|\\\\U[0-9a-fA-F]{8})*'";
		String STRING_LITERAL2_REGEX = "\"([^\"\\\\\\n\\r]|\\\\[tbnrf\"']|\\\\\\\\|\\\\u[0-9a-fA-F]{4}|\\\\U[0-9a-fA-F]{8})*\"";
		Pattern pattern = Pattern.compile("(" + STRING_LITERAL1_REGEX + "|"
				+ STRING_LITERAL2_REGEX + ")\\^\\^(.*)");
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()) {
			// typed literal
			String firstPart = matcher.group(1);
			String rest = value.substring(firstPart.length() + 2);
			return (isValidQName(rest) || isValidUrl(rest));
		} else {
			Pattern pattern2 = Pattern.compile(STRING_LITERAL1_REGEX + "|"
					+ STRING_LITERAL2_REGEX);
			Matcher matcher2 = pattern2.matcher(value);
			return matcher2.matches();
		}
	}

	/**
	 * Return true iff the argument is Q_IRI_REF accordingly to SPARQL grammar:
	 * http://www.w3.org/TR/rdf-sparql-query/#rQ_IRI_REF .
	 */
	public static boolean isValidUrl(String value) {
		Pattern pattern = Pattern.compile("<[^<>'{}|^`\u0000-\u0020]*>");
		Matcher matcher = pattern.matcher(value);
		return matcher.matches();
	}

	/**
	 * Return true iff the argument is either QNAME or QNAME_NS according to
	 * SPARQL grammar http://www.w3.org/TR/rdf-sparql-query/#rQNAME_NS ; We do
	 * not allow non-ASCII characters, but allow Unicode escapes &#x5c;uxxxx and
	 * &#x5c;Uxxxxxxxx
	 */
	public static boolean isValidQName(String value) {
		String NCNAME_REGEX = "([a-zA-Z_]|\\\\u[0-9a-fA-F]{4}|\\\\U[0-9a-fA-F]{8})(([a-zA-Z_0-9]|\\\\u[0-9a-fA-F]{4}|\\\\U[0-9a-fA-F]{8}|-|\\.)*([a-zA-Z_0-9]|\\\\u[0-9a-fA-F]{4}|\\\\U[0-9a-fA-F]{8}|-))?";
		String NCNAME_PREFIX_REGEX = "([a-zA-Z]|\\\\u[0-9a-fA-F]{4}|\\\\U[0-9a-fA-F]{8})(([a-zA-Z_0-9]|\\\\u[0-9a-fA-F]{4}|\\\\U[0-9a-fA-F]{8}|-|\\.)*([a-zA-Z_0-9]|\\\\u[0-9a-fA-F]{4}|\\\\U[0-9a-fA-F]{8}|-))?";

		Pattern pattern = Pattern.compile("(" + NCNAME_PREFIX_REGEX + ")?:("
				+ NCNAME_REGEX + ")?");
		Matcher matcher = pattern.matcher(value);
		return matcher.matches();
	}

	/**
	 * Return true iff the argument is a valid variable, i.e. VAR1 or VAR2
	 * according to SPARQL syntax - http://www.w3.org/TR/rdf-sparql-query/#rVAR1 ;
	 * We do not allow non-ASCII characters, but allow Unicode escapes
	 * &#x5c;uxxxx and &#x5c;Uxxxxxxxx
	 * 
	 * @param value
	 * @return
	 */
	public static boolean isValidVariable(String value) {
		Pattern pattern = Pattern
				.compile("(\\?|\\$)([a-zA-Z_0-9]|\\\\u[0-9a-fA-F]{4}|\\\\U[0-9a-fA-F]{8})+");
		Matcher matcher = pattern.matcher(value);
		return matcher.matches();
	}

	public static boolean isValid(String value) {
		return isValidLiteral(value) || isValidUrl(value)
				|| isValidQName(value) || isValidVariable(value);
	}
	
	public static String prefixesFromMap(Map<String,String> map) {
        String prefixes = "";
        Iterator<String> iter = map.keySet().iterator();
        while (iter.hasNext()) {
            String prefix = iter.next();
            prefixes += "PREFIX " + prefix + ": <" + map.get(prefix) + ">\n";
        }        
        return prefixes;        
    }

}
