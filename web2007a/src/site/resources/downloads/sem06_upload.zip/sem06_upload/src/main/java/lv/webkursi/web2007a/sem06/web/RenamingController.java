package lv.webkursi.web2007a.sem06.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class RenamingController implements Controller {

	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String pathInfo = request.getPathInfo();
		System.err.println("pathinfo in RenamingController is " + pathInfo);
		int indexOfSlash = pathInfo.lastIndexOf('/');
		String viewName = pathInfo.substring(indexOfSlash + 1);
		System.err.println("viewName in RenamingController is " + viewName);
		return new ModelAndView(viewName);
	}

}
