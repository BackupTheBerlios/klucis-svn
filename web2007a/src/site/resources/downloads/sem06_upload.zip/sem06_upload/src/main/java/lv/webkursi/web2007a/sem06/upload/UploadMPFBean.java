package lv.webkursi.web2007a.sem06.upload;

import org.springframework.web.multipart.MultipartFile;

public class UploadMPFBean {

    private MultipartFile file;

    public void setFile(MultipartFile file) {
        this.file = file;
    }

    public MultipartFile getFile() {
        return file;
    }
}