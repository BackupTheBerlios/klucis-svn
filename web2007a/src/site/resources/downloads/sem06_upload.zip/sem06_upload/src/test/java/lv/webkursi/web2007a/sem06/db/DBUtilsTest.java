package lv.webkursi.web2007a.sem06.db;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import lv.webkursi.web2007a.sem06.upload.UploadToBytesBean;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DBUtilsTest {
	
	DBUtils dbUtils;
	
	@Before
	public void setUp() {
		dbUtils = new DBUtils();
		dbUtils.open();		
	}
	
	@After
	public void tearDown() {
		dbUtils.deleteAllImages();
		dbUtils.close();
		dbUtils = null;
	}
	
	@Test
	public void insertSomething() {
		int result = dbUtils.insertImage(new byte[] {'a','b','c'}, new Date(), "text/plain", "testDescription", 't');
		assertTrue(result > 0);
	}

	@Test
	public void insertAndSelect() {
		int result = dbUtils.insertImage("def".getBytes(), new Date(), "text/plain", "testDescription1", 't');
		UploadToBytesBean bean = dbUtils.getImage(result);
		assertEquals("testDescription1",bean.getDescription());
	}
	
	
	
}
