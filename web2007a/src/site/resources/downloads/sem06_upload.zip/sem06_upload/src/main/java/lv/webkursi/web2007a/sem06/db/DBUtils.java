package lv.webkursi.web2007a.sem06.db;

import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import lv.webkursi.web2007a.sem06.upload.UploadToBytesBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DBUtils {

	Log log = LogFactory.getLog(DBUtils.class);

	protected String dbUrl = "jdbc:mysql://localhost/uploads";

	protected String dbDriver = "com.mysql.jdbc.Driver";

	protected String dbUser = "root";

	protected String dbPassword = "root";

	private Connection conn;

	private Statement stmt;

	private PreparedStatement pstmt;

	private ResultSet rs;

	public DBUtils() {
	}

	public void open() {
		try {
			Class.forName(dbDriver);
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
		} catch (Exception e) {
			e.printStackTrace(System.err);
			log.error(e);
		} finally {
			if (conn == null) {
				close();
				throw new RuntimeException("Could not open connection");
			}
		}
	}

	/**
	 * @param content
	 *            byte array containing image
	 * @param tstamp
	 *            timestamp, when the image was inserted or an explicitly set
	 *            creation date
	 * @param mime the MIME type of the image, e.g. "image/gif" etc. 
	 * @param description
	 *            some text to display as ALT attribute
	 * @param status
	 *            one letter classifier, which tells, if image is active in the
	 *            system, etc.
	 * @return the id of the image that was inserted
	 */
	public int insertImage(byte[] content, Date tstamp, String mime, String description,
			char status) {
		try {
			pstmt = conn
					.prepareStatement("INSERT INTO image VALUES (NULL,?,?,?,?,?)");
			pstmt.setBinaryStream(1, new ByteArrayInputStream(content),
					content.length);
			pstmt.setDate(2, new java.sql.Date(tstamp.getTime()));
			pstmt.setString(3, mime);
			pstmt.setString(4, description);
			pstmt.setString(5, "" + status);			
			int rows =  pstmt.executeUpdate();
			log.info("Inserted " + rows + " row(s)");
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select last_insert_id()");
			int result = 0;
			if (rs.next()) {
				result = rs.getInt(1);
			}
			rs.close();
			stmt.close();
			pstmt.close();
			return result;
		} catch (SQLException e) {
			log.error(e);
			e.printStackTrace(System.err);
			close();
			throw new RuntimeException("Could not insert an image");
		}
	}

	public int deleteAllImages() {
		try {
			stmt = conn.createStatement();
			int rows = stmt.executeUpdate("DELETE FROM image");
			stmt.close();
			return rows;			
		} catch (SQLException e) {
			log.error(e);
			e.printStackTrace(System.err);
			close();
			throw new RuntimeException("Could not insert an image");
		}
	}

	public void close() {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				log.error(e);
			}
			rs = null;
		}
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				log.error(e);
			}
			stmt = null;
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				log.error(e);
			}
			pstmt = null;
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				log.error(e);
			}
			conn = null;
		}
	}

	public UploadToBytesBean getImage(int id) {
		UploadToBytesBean result = new UploadToBytesBean();
		try {
			pstmt = conn
					.prepareStatement("SELECT * FROM image WHERE image_id=?");
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				result.setContent(rs.getBytes("content"));
				result.setTstamp(rs.getDate("tstamp"));
				result.setDescription(rs.getString("description"));
				result.setStatus(rs.getString("status").charAt(0));
			} else {
				throw new RuntimeException("Image for id = " + id
						+ " was not found");
			}
		} catch (SQLException e) {
			log.error(e);
			e.printStackTrace(System.err);
			close();
			throw new RuntimeException("Could not select with id = " + id);
		}
		return result;
	}

	public String getDbDriver() {
		return dbDriver;
	}

	public void setDbDriver(String dbDriver) {
		this.dbDriver = dbDriver;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}

	public String getDbUrl() {
		return dbUrl;
	}

	public void setDbUrl(String dbUrl) {
		this.dbUrl = dbUrl;
	}

	public String getDbUser() {
		return dbUser;
	}

	public void setDbUser(String dbUser) {
		this.dbUser = dbUser;
	}

}