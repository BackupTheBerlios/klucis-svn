package lv.webkursi.web2007a.sem06.upload;

import java.util.Date;

public class UploadToBytesBean {

    private byte[] content;
    
    private Date tstamp;
    
    private String description;

    private char status;
    
    public void setContent(byte[] content) {
        this.content = content;
    }

    public byte[] getContent() {
        return content;
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public Date getTstamp() {
		return tstamp;
	}

	public void setTstamp(Date tstamp) {
		this.tstamp = tstamp;
	}
}