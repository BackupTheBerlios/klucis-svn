package org.test.spring;

import java.util.Date;

import org.wymiwyg.wrhapi.Handler;
import org.wymiwyg.wrhapi.HandlerException;
import org.wymiwyg.wrhapi.HeaderName;
import org.wymiwyg.wrhapi.MessageBody;
import org.wymiwyg.wrhapi.Request;
import org.wymiwyg.wrhapi.Response;

public class SimpleHandler implements Handler {

	private MessageBody messageBodyWriter;

	public void setMessageBodyWriter(MessageBody messageBodyWriter) {
		this.messageBodyWriter = messageBodyWriter;
	}

	public void handle(Request request, Response response)
			throws HandlerException {
		final String host = request.getHeaderValues(HeaderName.HOST)[0];
		if (messageBodyWriter instanceof MessageBodyWriter) {
			((MessageBodyWriter) messageBodyWriter)
					.setMessage("Hello, the host is '" + host + "'<br />"
							+ (new Date()).toString());
		}
		response.setBody(messageBodyWriter);
	}
}
