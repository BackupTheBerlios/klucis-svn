package org.test.spring;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.wymiwyg.wrhapi.ServerBinding;

public class ServerBindingBean implements ServerBinding {
	
	private int port;
	
	private InetAddress inetAddress;
	
	private Log log = LogFactory.getLog(ServerBindingBean.class);

	public InetAddress getInetAddress() {
		return inetAddress;
	}

	public int getPort() {
		return port;
	}

	public void setHostName(String hostName) {
		try {
			if (hostName.equals("localhost")) {
				inetAddress = InetAddress.getLocalHost();
			}
			else {
				inetAddress = InetAddress.getByName(hostName);
			}
		} catch (UnknownHostException e) {
			log.warn("Host '" + hostName + "' not recognized",e);
		}
	}

	public void setPort(int port) {
		this.port = port;
	}

}
