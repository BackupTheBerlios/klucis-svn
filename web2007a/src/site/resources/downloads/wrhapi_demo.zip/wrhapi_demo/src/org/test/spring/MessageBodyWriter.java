package org.test.spring;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;

import org.wymiwyg.wrhapi.util.MessageBody2Write;

public class MessageBodyWriter extends MessageBody2Write {
	private String message; 
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void writeTo(WritableByteChannel out) throws IOException {
		PrintWriter writer = new PrintWriter(Channels.newWriter(out, "utf-8"));
		writer.println(message);
		writer.flush();
	}
}
