package org.test;

import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * @author kap
 */
public class DemoXmlSpring {
	public static void main(String[] args) {
		FileSystemXmlApplicationContext ctx = new FileSystemXmlApplicationContext(
				"conf/conf.xml");
		ctx.getBean("webServer");
	}
}
