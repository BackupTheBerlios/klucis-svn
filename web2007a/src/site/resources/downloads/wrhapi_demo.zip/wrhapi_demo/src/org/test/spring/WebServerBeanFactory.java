package org.test.spring;

import org.springframework.beans.factory.FactoryBean;
import org.wymiwyg.wrhapi.WebServerFactory;

import org.wymiwyg.wrhapi.Handler;
import org.wymiwyg.wrhapi.ServerBinding;

public class WebServerBeanFactory implements FactoryBean {

	private Handler handler;

	private ServerBinding serverBinding;

	public void setHandler(Handler handler) {
		this.handler = handler;
	}

	public void setServerBinding(ServerBinding serverBinding) {
		this.serverBinding = serverBinding;
	}

	public Object getObject() throws Exception {
		return WebServerFactory.newInstance().startNewWebServer(handler,
				serverBinding);
	}

	/**
	 * Which type this factory bean returns
	 */
	public Class getObjectType() {
		return org.wymiwyg.wrhapi.WebServer.class;
	}

	/**
	 * Should be false, if every time the factory is called, a different
	 * instance should be returned
	 */
	public boolean isSingleton() {
		return true;
	}
}
